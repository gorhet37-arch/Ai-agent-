// ============================================
// AI RECEPTIONIST WIDGET EMBED SCRIPT
// ============================================
// Usage: <script src="https://app.domain/embed.js" data-business-id="UUID"></script>
// This script injects the chat widget into any website.
// ============================================

(function() {
  const script = document.currentScript
  const businessId = script?.getAttribute('data-business-id')

  if (!businessId) {
    console.error('[AI Receptionist] data-business-id attribute is required')
    return
  }

  // Get app URL from script src
  const appUrl = script.src.split('/embed.js')[0]

  // Create container div
  const container = document.createElement('div')
  container.id = 'ai-receptionist-widget-root'
  document.body.appendChild(container)

  // Create iframe to embed widget
  const iframe = document.createElement('iframe')
  iframe.src = `${appUrl}/widget/${businessId}?embed=1`
  iframe.style.cssText = `
    position: fixed;
    bottom: 0;
    right: 0;
    width: 100%;
    height: 100%;
    border: none;
    z-index: 9999;
    background: transparent;
  `
  iframe.title = 'AI Receptionist Chat Widget'
  iframe.allow = 'camera; microphone'

  container.appendChild(iframe)

  // Optional: Send business_id to iframe via postMessage
  iframe.onload = function() {
    iframe.contentWindow.postMessage(
      { type: 'WIDGET_INIT', businessId },
      '*'
    )
  }
})()
