import Link from 'next/link'
import { Bot } from 'lucide-react'

const footerLinks = {
  'Product': [
    { label: 'Features', href: '#features' },
    { label: 'Pricing', href: '#pricing' },
    { label: 'How It Works', href: '#how-it-works' },
    { label: 'Changelog', href: '#' },
  ],
  'Company': [
    { label: 'About', href: '#' },
    { label: 'Blog', href: '#' },
    { label: 'Careers', href: '#' },
    { label: 'Contact', href: 'mailto:hello@aireceptionistpro.com' },
  ],
  'Legal': [
    { label: 'Terms of Service', href: '#' },
    { label: 'Privacy Policy', href: '#' },
    { label: 'Cookie Policy', href: '#' },
    { label: 'GDPR', href: '#' },
  ],
  'Support': [
    { label: 'Documentation', href: '#' },
    { label: 'Help Centre', href: '#' },
    { label: 'Status', href: '#' },
    { label: 'Email Support', href: 'mailto:support@aireceptionistpro.com' },
  ],
}

export default function Footer() {
  return (
    <footer className="bg-surface-950 border-t border-white/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-2 lg:grid-cols-5 gap-8 lg:gap-12">
          {/* Brand column */}
          <div className="col-span-2 lg:col-span-1">
            <Link href="/" className="flex items-center gap-2.5 mb-4">
              <div className="w-8 h-8 rounded-xl bg-brand-600 flex items-center justify-center">
                <Bot className="w-4 h-4 text-white" />
              </div>
              <span className="font-bold text-white text-sm">AI Receptionist <span className="text-brand-400">Pro</span></span>
            </Link>
            <p className="text-white/35 text-sm leading-relaxed">
              24/7 AI receptionist for local businesses. Capture leads while you sleep.
            </p>
          </div>

          {/* Link columns */}
          {Object.entries(footerLinks).map(([heading, links]) => (
            <div key={heading}>
              <h4 className="text-white/70 font-semibold text-xs uppercase tracking-widest mb-4">{heading}</h4>
              <ul className="space-y-2.5">
                {links.map(link => (
                  <li key={link.label}>
                    <Link href={link.href}
                      className="text-white/35 hover:text-white/70 text-sm transition-colors">
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="border-t border-white/5 mt-12 pt-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-white/25 text-xs">
            © {new Date().getFullYear()} AI Receptionist Pro. All rights reserved.
          </p>
          <div className="flex items-center gap-4 text-xs text-white/25">
            <span>🇺🇸 Serving US & UK businesses</span>
            <span>·</span>
            <span>SOC 2 compliant</span>
            <span>·</span>
            <span>GDPR ready</span>
          </div>
        </div>
      </div>
    </footer>
  )
}
