'use client'
import { useState } from 'react'
import Link from 'next/link'
import { Check, Zap, Crown, Building2, ArrowRight } from 'lucide-react'
import { cn } from '@/lib/utils'

const plans = [
  {
    id: 'starter',
    name: 'Starter',
    icon: Zap,
    price: { monthly: 29, annual: 23 },
    description: 'Perfect for small businesses ready to stop missing leads.',
    chats: '500 AI chats/month',
    highlight: 'Great for 1 location',
    features: [
      '500 AI chat conversations/month',
      'Lead capture & scoring (hot/warm/cold)',
      'Embeddable website chat widget',
      'Business profile & custom greeting',
      'Lead dashboard with search & filter',
      'Email notifications for new leads',
      '1 business profile',
      'Email support',
    ],
  },
  {
    id: 'professional',
    name: 'Professional',
    icon: Crown,
    price: { monthly: 79, annual: 63 },
    description: 'For growing businesses that need more power.',
    chats: '2,000 chats/month',
    highlight: 'Most popular choice',
    popular: true,
    features: [
      '2,000 AI chat conversations/month',
      'Everything in Starter',
      'Google Calendar integration',
      'Custom AI persona name & personality',
      'SMS lead notifications',
      'Appointment booking via chat',
      'Conversation history & export',
      'Remove "Powered by" branding',
      'Priority support',
    ],
  },
  {
    id: 'agency',
    name: 'Agency',
    icon: Building2,
    price: { monthly: 199, annual: 159 },
    description: 'Manage multiple clients under one roof.',
    chats: 'Unlimited chats',
    highlight: 'For agencies & franchises',
    features: [
      'Unlimited AI chat conversations',
      'Everything in Professional',
      'Up to 25 business profiles',
      'White-label widget & branding',
      'API access for integrations',
      'Admin panel for all clients',
      'Bulk onboarding tools',
      'Custom AI training per client',
      'Dedicated account manager',
      'Priority phone & SLA support',
    ],
  },
]

const comparisons = [
  { name: 'In-house receptionist', cost: '$3,000–4,500/mo', note: 'Salary + benefits + holidays' },
  { name: 'Answering service', cost: '$300–900/mo', note: 'Per-minute billing, no lead capture' },
  { name: 'Generic chatbot', cost: '$100–500/mo', note: 'No AI, scripted responses only' },
  { name: 'AI Receptionist Pro', cost: 'From $29/mo', note: '24/7, lead capture, AI-powered', highlight: true },
]

export default function Pricing() {
  const [annual, setAnnual] = useState(false)

  return (
    <section id="pricing" className="py-24 bg-surface-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-14">
          <div className="inline-flex items-center gap-2 bg-brand-50 text-brand-700 border border-brand-100 rounded-full px-4 py-2 mb-5 text-sm font-semibold">
            <Zap className="w-4 h-4" /> Transparent Pricing
          </div>
          <h2 className="text-4xl lg:text-5xl font-bold text-surface-900 mb-4">
            A fraction of the cost of hiring
          </h2>
          <p className="text-xl text-surface-500 max-w-2xl mx-auto mb-8">
            No setup fees. No per-minute billing. No hidden costs.
            Start free, upgrade when you&apos;re ready.
          </p>

          {/* Billing toggle */}
          <div className="inline-flex items-center gap-3 bg-white rounded-xl border border-surface-200 p-1.5 shadow-card">
            <button
              onClick={() => setAnnual(false)}
              className={cn(
                'px-5 py-2 rounded-lg text-sm font-semibold transition-all',
                !annual ? 'bg-brand-600 text-white shadow-sm' : 'text-surface-500 hover:text-surface-800'
              )}
            >
              Monthly
            </button>
            <button
              onClick={() => setAnnual(true)}
              className={cn(
                'flex items-center gap-2 px-5 py-2 rounded-lg text-sm font-semibold transition-all',
                annual ? 'bg-brand-600 text-white shadow-sm' : 'text-surface-500 hover:text-surface-800'
              )}
            >
              Annual
              <span className="text-xs bg-success-100 text-success-700 px-2 py-0.5 rounded-full font-semibold">
                Save 20%
              </span>
            </button>
          </div>
        </div>

        {/* Plans grid */}
        <div className="grid lg:grid-cols-3 gap-6 items-start mb-14">
          {plans.map(plan => (
            <div
              key={plan.id}
              className={cn(
                'relative rounded-2xl border-2 bg-white overflow-hidden transition-all duration-300 hover:-translate-y-1',
                plan.popular
                  ? 'border-brand-500 shadow-glow'
                  : 'border-surface-200 shadow-card hover:shadow-card-hover'
              )}
            >
              {plan.popular && (
                <div className="bg-brand-600 text-white text-center text-xs font-bold py-2.5 tracking-wider uppercase">
                  ⭐ Most Popular
                </div>
              )}

              <div className="p-8">
                {/* Icon + Name */}
                <div className="flex items-start justify-between mb-5">
                  <div className="flex items-center gap-3">
                    <div className={cn(
                      'w-11 h-11 rounded-xl flex items-center justify-center',
                      plan.popular ? 'bg-brand-100 text-brand-600' : 'bg-surface-100 text-surface-600'
                    )}>
                      <plan.icon className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="font-bold text-surface-900">{plan.name}</div>
                      <div className="text-xs text-surface-400">{plan.chats}</div>
                    </div>
                  </div>
                  <span className="text-xs bg-surface-100 text-surface-500 px-2 py-1 rounded-lg font-medium">
                    {plan.highlight}
                  </span>
                </div>

                <p className="text-surface-500 text-sm mb-6 leading-relaxed">{plan.description}</p>

                {/* Price */}
                <div className="mb-6">
                  <div className="flex items-end gap-1">
                    <span className="text-4xl font-bold text-surface-900">
                      ${annual ? plan.price.annual : plan.price.monthly}
                    </span>
                    <span className="text-surface-400 mb-1.5 text-sm">/mo</span>
                  </div>
                  {annual ? (
                    <p className="text-sm text-success-600 font-medium mt-1">
                      Billed annually — ${(plan.price.monthly - plan.price.annual) * 12}/year saved
                    </p>
                  ) : (
                    <p className="text-xs text-surface-400 mt-1">
                      or ${plan.price.annual}/mo billed annually
                    </p>
                  )}
                </div>

                {/* CTA */}
                <Link href="/auth/register"
                  className={cn(
                    'w-full btn btn-lg justify-center gap-2',
                    plan.popular ? 'btn-primary' : 'btn-secondary'
                  )}
                >
                  Start Free Trial
                  <ArrowRight className="w-4 h-4" />
                </Link>

                {/* Features */}
                <ul className="mt-7 space-y-2.5">
                  {plan.features.map(feature => (
                    <li key={feature} className="flex items-start gap-3 text-sm text-surface-600">
                      <Check className="w-4 h-4 text-success-500 shrink-0 mt-0.5" />
                      {feature}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          ))}
        </div>

        {/* Cost comparison */}
        <div className="bg-white rounded-2xl border border-surface-200 shadow-card overflow-hidden mb-8">
          <div className="p-6 border-b border-surface-100">
            <h3 className="font-bold text-surface-900 text-lg">Compare the real cost</h3>
            <p className="text-surface-500 text-sm mt-1">How AI Receptionist Pro stacks up against alternatives</p>
          </div>
          <div className="divide-y divide-surface-100">
            {comparisons.map(c => (
              <div key={c.name} className={cn(
                'flex items-center justify-between px-6 py-4 gap-4',
                c.highlight && 'bg-brand-50'
              )}>
                <div className="flex items-center gap-3">
                  {c.highlight && <div className="w-2 h-2 rounded-full bg-success-500 shrink-0" />}
                  <div>
                    <p className={cn('font-semibold text-sm', c.highlight ? 'text-brand-700' : 'text-surface-700')}>
                      {c.name}
                    </p>
                    <p className="text-xs text-surface-400">{c.note}</p>
                  </div>
                </div>
                <span className={cn(
                  'text-sm font-bold shrink-0',
                  c.highlight ? 'text-brand-600 text-base' : 'text-surface-600'
                )}>
                  {c.cost}
                </span>
              </div>
            ))}
          </div>
        </div>

        <p className="text-center text-surface-400 text-sm">
          All plans include a 14-day free trial. No credit card required to start.
          Cancel anytime — no lock-in contracts.
        </p>
      </div>
    </section>
  )
}
