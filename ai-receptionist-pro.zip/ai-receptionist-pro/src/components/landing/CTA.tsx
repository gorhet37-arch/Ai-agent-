import Link from 'next/link'
import { ArrowRight, CheckCircle2 } from 'lucide-react'

const points = [
  'No credit card required',
  '14-day free trial',
  'Setup in under 5 minutes',
  'Cancel any time',
]

export default function CTA() {
  return (
    <section className="py-24 bg-surface-900 overflow-hidden relative">
      {/* Background glow */}
      <div className="absolute inset-0 pointer-events-none"
           style={{ background: 'radial-gradient(ellipse at 50% 0%, rgba(12,126,234,0.25) 0%, transparent 60%), radial-gradient(ellipse at 80% 100%, rgba(195,68,237,0.15) 0%, transparent 60%)' }} />

      <div className="relative max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <div className="inline-flex items-center gap-2 bg-white/10 border border-white/15 rounded-full px-4 py-2 mb-8 text-sm font-semibold text-white/80">
          <span className="w-2 h-2 rounded-full bg-success-400 animate-pulse" />
          Start answering leads in 5 minutes
        </div>

        <h2 className="text-4xl lg:text-6xl font-bold text-white mb-6 leading-tight">
          Never miss a lead again.
          <span className="block text-transparent bg-clip-text bg-gradient-to-r from-brand-300 to-accent-300">
            Start your free trial.
          </span>
        </h2>

        <p className="text-xl text-white/60 max-w-2xl mx-auto mb-10 leading-relaxed">
          Join 10,000+ local businesses that use AI Receptionist Pro to handle
          enquiries, capture leads, and book appointments around the clock.
        </p>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-10">
          <Link href="/auth/register"
            className="btn bg-white text-brand-700 hover:bg-brand-50 shadow-glow btn-xl gap-3 font-bold w-full sm:w-auto justify-center">
            Start Free — No Card Required
            <ArrowRight className="w-5 h-5" />
          </Link>
          <Link href="#pricing"
            className="btn bg-white/10 border border-white/20 text-white hover:bg-white/20 btn-xl w-full sm:w-auto justify-center">
            View Pricing
          </Link>
        </div>

        <div className="flex flex-wrap items-center justify-center gap-x-6 gap-y-2">
          {points.map(p => (
            <div key={p} className="flex items-center gap-2 text-white/50 text-sm">
              <CheckCircle2 className="w-4 h-4 text-success-400" />
              {p}
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
