'use client'
import { useState } from 'react'
import { Plus, Minus } from 'lucide-react'
import { cn } from '@/lib/utils'

const faqs = [
  {
    q: 'How does the AI know about my business?',
    a: 'During setup you fill in your business profile: name, services, pricing, hours, and FAQs. The AI is trained on this information and uses it to answer visitor questions accurately and confidently. The more detail you add, the better it performs.',
  },
  {
    q: 'What happens when the AI can\'t answer a question?',
    a: "If a question falls outside what the AI knows, it tells the visitor politely and offers to take their contact details so you can follow up personally. It never makes up answers or guesses — only responds with what you've provided.",
  },
  {
    q: 'Does it actually book appointments?',
    a: 'Yes — on the Professional and Agency plans, you can connect your Google Calendar. The AI will offer available slots to visitors and create confirmed bookings directly in your calendar. No back-and-forth phone calls required.',
  },
  {
    q: 'What does "hot/warm/cold" lead scoring mean?',
    a: 'The AI analyses each conversation to evaluate how ready a visitor is to become a customer. Hot leads showed strong intent (e.g. ready to book now). Warm leads are interested but not quite ready. Cold leads asked general questions. This helps you prioritise who to follow up with first.',
  },
  {
    q: 'How do I add the widget to my website?',
    a: 'You get a single line of JavaScript code from your dashboard. Paste it anywhere before the </body> tag on your website. It works with WordPress, Wix, Squarespace, Webflow, Shopify, and any other website platform — no developer needed.',
  },
  {
    q: 'Is there a free trial?',
    a: 'Yes — every plan starts with a 14-day free trial. No credit card required to get started. You can set up your AI, embed it on your site, and start capturing leads before you pay anything.',
  },
  {
    q: 'What counts as a "chat"?',
    a: 'A chat is one complete conversation with a visitor — from their first message to when the conversation ends. A single visitor asking ten questions counts as one chat. Monthly limits reset at the start of each billing period.',
  },
  {
    q: 'Can I customise how the AI sounds?',
    a: 'Absolutely. You can give the AI a custom name (the default is "Alex"), write a custom greeting message, and define its tone through the services and FAQs you add. The Professional plan includes deeper personalisation options.',
  },
  {
    q: 'Is my data secure?',
    a: 'Yes. All data is encrypted in transit and at rest. We use Supabase (built on Postgres with row-level security) and never sell or share your data or your customers\' data with third parties. We are GDPR-compliant.',
  },
  {
    q: 'Can I cancel at any time?',
    a: 'Yes — no lock-in contracts. You can cancel your subscription at any time from your account settings. Your account stays active until the end of the current billing period.',
  },
]

export default function FAQ() {
  const [open, setOpen] = useState<number | null>(0)

  return (
    <section id="faq" className="py-24 bg-surface-50">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-14">
          <div className="inline-flex items-center gap-2 bg-white border border-surface-200 text-surface-600 rounded-full px-4 py-2 mb-5 text-sm font-semibold shadow-card">
            Got questions?
          </div>
          <h2 className="text-4xl font-bold text-surface-900 mb-4">Frequently Asked Questions</h2>
          <p className="text-xl text-surface-500">
            Everything you need to know about AI Receptionist Pro.
          </p>
        </div>

        <div className="space-y-3">
          {faqs.map((faq, i) => (
            <div key={i} className={cn(
              'bg-white rounded-xl border transition-all duration-200',
              open === i ? 'border-brand-200 shadow-card' : 'border-surface-200 hover:border-surface-300'
            )}>
              <button
                onClick={() => setOpen(open === i ? null : i)}
                className="w-full flex items-center justify-between gap-4 px-5 py-4 text-left"
              >
                <span className={cn(
                  'font-semibold text-sm transition-colors',
                  open === i ? 'text-brand-700' : 'text-surface-800'
                )}>
                  {faq.q}
                </span>
                <div className={cn(
                  'w-6 h-6 rounded-full flex items-center justify-center shrink-0 transition-colors',
                  open === i ? 'bg-brand-100 text-brand-600' : 'bg-surface-100 text-surface-500'
                )}>
                  {open === i
                    ? <Minus className="w-3 h-3" />
                    : <Plus className="w-3 h-3" />
                  }
                </div>
              </button>
              {open === i && (
                <div className="px-5 pb-5">
                  <p className="text-surface-500 text-sm leading-relaxed">{faq.a}</p>
                </div>
              )}
            </div>
          ))}
        </div>

        <p className="text-center text-surface-400 text-sm mt-10">
          Still have questions?{' '}
          <a href="mailto:support@aireceptionistpro.com"
            className="text-brand-600 hover:text-brand-700 font-semibold">
            Email our team →
          </a>
        </p>
      </div>
    </section>
  )
}
