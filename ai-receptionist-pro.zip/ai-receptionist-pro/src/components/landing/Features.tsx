import {
  Zap, Users, Calendar, Clock, MessageSquare,
  BarChart3, Globe, Shield
} from 'lucide-react'

const features = [
  {
    icon: Zap,
    title: 'Instant AI Responses',
    desc: 'Answers visitor questions in under a second — no hold music, no voicemail. Your AI knows your business inside out.',
    color: 'text-yellow-500',
    bg: 'bg-yellow-50',
  },
  {
    icon: Users,
    title: 'Automatic Lead Capture',
    desc: 'Every conversation is an opportunity. The AI collects names, emails, and phone numbers — and scores each lead hot, warm, or cold.',
    color: 'text-brand-600',
    bg: 'bg-brand-50',
  },
  {
    icon: Calendar,
    title: 'Appointment Booking',
    desc: 'Integrates with Google Calendar. Visitors can book appointments directly through the chat, no phone tag required.',
    color: 'text-success-600',
    bg: 'bg-success-50',
  },
  {
    icon: Clock,
    title: '24/7 Availability',
    desc: 'Works while you sleep, on weekends, and on holidays. You never miss a lead because it was after hours.',
    color: 'text-accent-600',
    bg: 'bg-accent-50',
  },
  {
    icon: MessageSquare,
    title: 'Trained on Your Business',
    desc: 'Add your services, pricing, FAQs, and hours. The AI gives accurate, specific answers about your business — not generic responses.',
    color: 'text-blue-600',
    bg: 'bg-blue-50',
  },
  {
    icon: Globe,
    title: 'Works on Any Website',
    desc: 'One line of code. Works with WordPress, Wix, Squarespace, Webflow, Shopify — any website with a body tag.',
    color: 'text-teal-600',
    bg: 'bg-teal-50',
  },
  {
    icon: BarChart3,
    title: 'Lead Dashboard',
    desc: 'View all captured leads, filter by score, and see contact details at a glance. Export to your CRM whenever you need.',
    color: 'text-orange-500',
    bg: 'bg-orange-50',
  },
  {
    icon: Shield,
    title: 'Secure & Private',
    desc: 'GDPR-ready. All conversations are encrypted. No third-party data selling. Your business data stays yours.',
    color: 'text-danger-500',
    bg: 'bg-danger-50',
  },
]

export default function Features() {
  return (
    <section id="features" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 bg-brand-50 text-brand-700 border border-brand-100 rounded-full px-4 py-2 mb-5 text-sm font-semibold">
            Everything you need
          </div>
          <h2 className="text-4xl lg:text-5xl font-bold text-surface-900 mb-4">
            One widget. Unlimited possibilities.
          </h2>
          <p className="text-xl text-surface-500 max-w-2xl mx-auto">
            AI Receptionist Pro handles every stage of the customer journey —
            from first question to confirmed appointment.
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map(f => (
            <div key={f.title} className="card-hover p-6 group">
              <div className={`w-11 h-11 rounded-xl ${f.bg} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300`}>
                <f.icon className={`w-5 h-5 ${f.color}`} />
              </div>
              <h3 className="font-bold text-surface-900 mb-2 text-base">{f.title}</h3>
              <p className="text-surface-500 text-sm leading-relaxed">{f.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
