'use client'
import { useState, useEffect } from 'react'
import Link from 'next/link'
import { Bot, Menu, X, ChevronRight } from 'lucide-react'
import { cn } from '@/lib/utils'

const NAV_LINKS = [
  { href: '#features', label: 'Features' },
  { href: '#how-it-works', label: 'How it Works' },
  { href: '#pricing', label: 'Pricing' },
  { href: '#faq', label: 'FAQ' },
]

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false)
  const [mobileOpen, setMobileOpen] = useState(false)

  useEffect(() => {
    const handler = () => setScrolled(window.scrollY > 16)
    window.addEventListener('scroll', handler, { passive: true })
    return () => window.removeEventListener('scroll', handler)
  }, [])

  const handleAnchor = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    if (!href.startsWith('#')) return
    e.preventDefault()
    setMobileOpen(false)
    const el = document.querySelector(href)
    if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' })
  }

  return (
    <>
      <nav className={cn(
        'fixed top-0 left-0 right-0 z-40 transition-all duration-300',
        scrolled
          ? 'bg-white/95 backdrop-blur-md border-b border-surface-100 shadow-sm'
          : 'bg-transparent'
      )}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <Link href="/" className="flex items-center gap-2.5 shrink-0">
              <div className="w-8 h-8 rounded-xl bg-brand-600 flex items-center justify-center shadow-glow-sm">
                <Bot className="w-4.5 h-4.5 text-white" style={{ width: 18, height: 18 }} />
              </div>
              <span className={cn(
                'font-bold text-base transition-colors',
                scrolled ? 'text-surface-900' : 'text-white'
              )}>
                AI Receptionist <span className={scrolled ? 'text-brand-600' : 'text-brand-300'}>Pro</span>
              </span>
            </Link>

            {/* Desktop nav */}
            <div className="hidden md:flex items-center gap-1">
              {NAV_LINKS.map(link => (
                <a key={link.href} href={link.href}
                  onClick={e => handleAnchor(e, link.href)}
                  className={cn(
                    'px-4 py-2 rounded-lg text-sm font-medium transition-colors cursor-pointer',
                    scrolled
                      ? 'text-surface-600 hover:text-surface-900 hover:bg-surface-100'
                      : 'text-white/75 hover:text-white hover:bg-white/10'
                  )}
                >
                  {link.label}
                </a>
              ))}
            </div>

            {/* Desktop CTA */}
            <div className="hidden md:flex items-center gap-3">
              <Link href="/auth/login"
                className={cn(
                  'text-sm font-semibold px-4 py-2 rounded-lg transition-colors',
                  scrolled ? 'text-surface-700 hover:text-surface-900' : 'text-white/80 hover:text-white'
                )}>
                Sign In
              </Link>
              <Link href="/auth/register"
                className="btn btn-primary btn-sm gap-1.5">
                Start Free Trial
                <ChevronRight className="w-3.5 h-3.5" />
              </Link>
            </div>

            {/* Mobile toggle */}
            <button
              className={cn(
                'md:hidden p-2 rounded-lg transition-colors',
                scrolled ? 'text-surface-700 hover:bg-surface-100' : 'text-white hover:bg-white/10'
              )}
              onClick={() => setMobileOpen(!mobileOpen)}
              aria-label="Toggle menu"
            >
              {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </nav>

      {/* Mobile drawer */}
      {mobileOpen && (
        <div className="fixed inset-0 z-30 md:hidden">
          <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={() => setMobileOpen(false)} />
          <div className="absolute top-16 left-0 right-0 bg-white shadow-modal border-b border-surface-100 animate-scale-in">
            <div className="px-4 py-4 space-y-1">
              {NAV_LINKS.map(link => (
                <a key={link.href} href={link.href}
                  onClick={e => handleAnchor(e, link.href)}
                  className="flex items-center justify-between px-3 py-3 rounded-xl text-sm font-medium text-surface-700 hover:bg-surface-100 transition-colors cursor-pointer">
                  {link.label}
                  <ChevronRight className="w-4 h-4 text-surface-400" />
                </a>
              ))}
            </div>
            <div className="px-4 py-4 border-t border-surface-100 flex flex-col gap-3">
              <Link href="/auth/register"
                onClick={() => setMobileOpen(false)}
                className="btn btn-primary btn-md w-full justify-center">
                Start Free Trial — No Card Needed
              </Link>
              <Link href="/auth/login"
                onClick={() => setMobileOpen(false)}
                className="btn btn-secondary btn-md w-full justify-center">
                Sign In
              </Link>
            </div>
          </div>
        </div>
      )}
    </>
  )
}
