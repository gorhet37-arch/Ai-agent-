'use client'
import { useState } from 'react'
import Link from 'next/link'
import { ArrowRight, CheckCircle2, Play, X, Bot } from 'lucide-react'

const industries = ['Dentists', 'Law Firms', 'HVAC', 'Real Estate', 'Clinics', 'Plumbers', 'Salons']
const stats = [
  { value: '10,000+', label: 'Businesses' },
  { value: '2.4M+',   label: 'Chats handled' },
  { value: '98%',     label: 'Satisfaction' },
  { value: '24/7',    label: 'Always on' },
]

export default function Hero() {
  const [demoOpen, setDemoOpen] = useState(false)

  return (
    <section className="relative min-h-screen flex items-center pt-16 overflow-hidden bg-surface-900">
      {/* Background gradient */}
      <div className="absolute inset-0"
           style={{ background: 'radial-gradient(ellipse at 25% 25%, rgba(0,95,200,0.35) 0%, transparent 55%), radial-gradient(ellipse at 75% 75%, rgba(168,37,209,0.2) 0%, transparent 55%), linear-gradient(to bottom right, #0a356e, #0f172a, #020617)' }} />
      {/* Grid */}
      <div className="absolute inset-0 opacity-[0.05]"
           style={{ backgroundImage: 'linear-gradient(rgba(255,255,255,1) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,1) 1px, transparent 1px)', backgroundSize: '64px 64px' }} />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 lg:py-28">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
          {/* Left */}
          <div className="animate-fade-in-up">
            <div className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-sm border border-white/15 rounded-full px-4 py-2 mb-8">
              <span className="w-2 h-2 rounded-full bg-success-400 animate-pulse" />
              <span className="text-white/85 text-sm font-medium">Trusted by 10,000+ local businesses</span>
            </div>

            <h1 className="text-5xl lg:text-6xl xl:text-7xl font-bold text-white leading-[1.05] mb-6">
              Your Business,{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand-300 to-accent-300">
                Always On
              </span>
            </h1>

            <p className="text-lg text-white/65 leading-relaxed mb-10 max-w-xl">
              Replace your front desk with an AI receptionist that answers questions,
              qualifies leads, and books appointments — 24 hours a day, 7 days a week.
            </p>

            <div className="flex flex-col gap-3 mb-10">
              {[
                'Answer questions instantly — no hold time',
                'Capture & qualify leads automatically',
                'Book appointments directly in your calendar',
              ].map(b => (
                <div key={b} className="flex items-center gap-3">
                  <CheckCircle2 className="w-5 h-5 text-success-400 shrink-0" />
                  <span className="text-white/75 text-sm">{b}</span>
                </div>
              ))}
            </div>

            <div className="flex flex-col sm:flex-row gap-3">
              <Link href="/auth/register"
                className="btn btn-lg gap-2 bg-white text-brand-700 hover:bg-brand-50 shadow-glow font-bold">
                Start Free 14-Day Trial
                <ArrowRight className="w-5 h-5" />
              </Link>
              <button
                onClick={() => setDemoOpen(true)}
                className="btn btn-lg gap-2 bg-white/10 backdrop-blur-sm text-white border border-white/20 hover:bg-white/20">
                <Play className="w-5 h-5" />
                Watch Demo
              </button>
            </div>
            <p className="text-white/35 text-xs mt-4">No credit card required · Setup in under 5 minutes</p>
          </div>

          {/* Right: Chat Preview */}
          <div className="animate-slide-in-right animation-delay-300">
            <div className="relative">
              <div className="absolute -inset-6 bg-brand-500/15 rounded-3xl blur-3xl" />
              <div className="relative bg-white/95 backdrop-blur rounded-2xl shadow-modal overflow-hidden border border-white/20">
                {/* Chat header */}
                <div className="bg-gradient-to-r from-brand-600 to-brand-700 px-5 py-4 flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center">
                    <Bot className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <div className="text-white font-semibold text-sm">Alex — AI Receptionist</div>
                    <div className="flex items-center gap-1.5">
                      <span className="w-1.5 h-1.5 rounded-full bg-success-400 animate-pulse" />
                      <span className="text-white/65 text-xs">Online · Replies instantly</span>
                    </div>
                  </div>
                </div>
                {/* Messages */}
                <div className="p-5 space-y-4 bg-surface-50 min-h-[260px]">
                  <div className="flex gap-3">
                    <div className="w-7 h-7 rounded-full bg-brand-100 flex items-center justify-center shrink-0 mt-0.5">
                      <Bot className="w-4 h-4 text-brand-600" />
                    </div>
                    <div className="chat-bubble-assistant text-xs">
                      Hi! I&apos;m Alex from <strong>Bright Smile Dental</strong>. How can I help you today? 😊
                    </div>
                  </div>
                  <div className="flex justify-end">
                    <div className="chat-bubble-user text-xs">I need to schedule a teeth cleaning next week</div>
                  </div>
                  <div className="flex gap-3">
                    <div className="w-7 h-7 rounded-full bg-brand-100 flex items-center justify-center shrink-0 mt-0.5">
                      <Bot className="w-4 h-4 text-brand-600" />
                    </div>
                    <div className="chat-bubble-assistant text-xs">
                      Great! We have openings on <strong>Monday at 10am</strong> or <strong>Wednesday at 2pm</strong>. Which works for you?
                    </div>
                  </div>
                  <div className="flex justify-end">
                    <div className="chat-bubble-user text-xs">Monday at 10am works!</div>
                  </div>
                  <div className="flex gap-3">
                    <div className="w-7 h-7 rounded-full bg-brand-100 flex items-center justify-center shrink-0 mt-0.5">
                      <Bot className="w-4 h-4 text-brand-600" />
                    </div>
                    <div className="chat-bubble-assistant text-xs">
                      Perfect! Could I get your name and email to confirm the booking? 📅
                    </div>
                  </div>
                  <div className="flex justify-end">
                    <div className="flex gap-1 items-center bg-brand-600 rounded-2xl rounded-tr-md px-4 py-3 shadow-sm">
                      {[0,1,2].map(i => (
                        <span key={i} className="w-1.5 h-1.5 rounded-full bg-white/60 animate-bounce"
                          style={{ animationDelay: `${i * 150}ms` }} />
                      ))}
                    </div>
                  </div>
                </div>
                {/* Input */}
                <div className="border-t border-surface-100 p-3 flex gap-2 bg-white">
                  <input type="text" placeholder="Type a message..." readOnly
                    className="flex-1 text-xs bg-surface-50 border border-surface-200 rounded-xl px-3 py-2 outline-none" />
                  <button className="bg-brand-600 text-white rounded-xl px-4 py-2 text-xs font-semibold">Send</button>
                </div>
              </div>

              {/* Floating badges */}
              <div className="absolute -top-3 -right-3 bg-white rounded-xl shadow-card-hover px-3 py-2 flex items-center gap-2 animate-fade-in animation-delay-500 border border-surface-100">
                <span className="text-success-500 text-sm">✓</span>
                <span className="text-xs font-semibold text-surface-700">Appointment Booked!</span>
              </div>
              <div className="absolute -bottom-3 -left-3 bg-white rounded-xl shadow-card-hover px-3 py-2 flex items-center gap-2 animate-fade-in animation-delay-400 border border-surface-100">
                <span className="text-sm">🔥</span>
                <span className="text-xs font-semibold text-surface-700">New Hot Lead</span>
              </div>
            </div>
          </div>
        </div>

        {/* Stats row */}
        <div className="mt-20 grid grid-cols-2 lg:grid-cols-4 gap-6 animate-fade-in animation-delay-500">
          {stats.map(s => (
            <div key={s.label} className="text-center">
              <div className="text-3xl font-bold text-white mb-1">{s.value}</div>
              <div className="text-white/40 text-sm">{s.label}</div>
            </div>
          ))}
        </div>

        {/* Industry tags */}
        <div className="mt-10 flex items-center justify-center gap-2 flex-wrap animate-fade-in animation-delay-600">
          <span className="text-white/35 text-xs">Built for:</span>
          {industries.map(ind => (
            <span key={ind} className="bg-white/8 border border-white/10 text-white/60 text-xs rounded-full px-3 py-1">
              {ind}
            </span>
          ))}
          <span className="text-white/35 text-xs">& more</span>
        </div>
      </div>

      {/* Demo Modal */}
      {demoOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm"
             onClick={() => setDemoOpen(false)}>
          <div className="bg-white rounded-2xl shadow-modal w-full max-w-2xl p-8 animate-scale-in"
               onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-6">
              <h3 className="font-bold text-surface-900 text-xl">Product Demo</h3>
              <button onClick={() => setDemoOpen(false)}
                className="p-2 rounded-lg hover:bg-surface-100 text-surface-400">
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="aspect-video bg-surface-100 rounded-xl flex flex-col items-center justify-center gap-3 mb-6 border border-surface-200">
              <Play className="w-12 h-12 text-surface-300" />
              <p className="text-surface-400 text-sm">Demo video coming soon</p>
            </div>
            <div className="flex gap-3">
              <Link href="/auth/register"
                onClick={() => setDemoOpen(false)}
                className="btn btn-primary btn-md flex-1 justify-center">
                Start Free Trial Instead
              </Link>
              <button onClick={() => setDemoOpen(false)} className="btn btn-secondary btn-md">
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  )
}
