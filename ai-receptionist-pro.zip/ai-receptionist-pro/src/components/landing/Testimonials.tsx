import { Star } from 'lucide-react'

const testimonials = [
  {
    quote: "We were missing about 40% of our incoming calls. AI Receptionist Pro now handles every inquiry and books appointments directly. We've seen a 30% uptick in new patients this quarter.",
    author: 'Dr. Sarah Chen',
    role: 'Owner, Bright Smile Dental',
    avatar: 'SC',
    industry: 'Dental Practice',
    stat: '+30% new patients',
  },
  {
    quote: "As a solo attorney I couldn't afford a receptionist. This pays for itself every month just in the leads it captures after hours. Setup took about 10 minutes.",
    author: 'Marcus Williams',
    role: 'Attorney at Law',
    avatar: 'MW',
    industry: 'Law Firm',
    stat: '10x ROI',
  },
  {
    quote: "Our HVAC business gets hammered in summer. The AI handles hundreds of chat inquiries a day and qualifies every lead. Our close rate on AI leads is actually higher than cold calls.",
    author: 'Jennifer Okafor',
    role: 'Operations Manager, CoolPro HVAC',
    avatar: 'JO',
    industry: 'HVAC',
    stat: 'Higher close rate',
  },
  {
    quote: "I manage 12 property listings. Having an AI that can answer questions about each property 24/7 and collect buyer info has been a game changer. Highly recommend.",
    author: 'David Park',
    role: 'Real Estate Broker',
    avatar: 'DP',
    industry: 'Real Estate',
    stat: '12 listings managed',
  },
  {
    quote: "The chat quality is genuinely impressive. Customers say it feels natural, not like a bot. And the lead scoring actually helps me prioritise who to call first.",
    author: 'Priya Sharma',
    role: 'Owner, Pure Balance Wellness',
    avatar: 'PS',
    industry: 'Health & Wellness',
    stat: 'Natural conversations',
  },
  {
    quote: "Switched from a $400/mo answering service. This is cheaper, captures more leads, and never takes a sick day. Couldn't be happier.",
    author: 'Tom Reilly',
    role: 'Owner, Reilly Plumbing & Heating',
    avatar: 'TR',
    industry: 'Plumbing',
    stat: 'Saved $370/month',
  },
]

export default function Testimonials() {
  return (
    <section className="py-24 bg-white overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 bg-yellow-50 text-yellow-700 border border-yellow-200 rounded-full px-4 py-2 mb-5 text-sm font-semibold">
            <Star className="w-3.5 h-3.5 fill-yellow-500 text-yellow-500" />
            Loved by local businesses
          </div>
          <h2 className="text-4xl lg:text-5xl font-bold text-surface-900 mb-4">
            Real businesses, real results
          </h2>
          <p className="text-xl text-surface-500 max-w-2xl mx-auto">
            Trusted by over 10,000 businesses across the US and UK.
            Here&apos;s what they say after their first month.
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {testimonials.map((t) => (
            <div key={t.author} className="card-hover p-6 flex flex-col">
              {/* Stars */}
              <div className="flex gap-1 mb-4">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                ))}
              </div>

              {/* Stat pill */}
              <div className="inline-flex self-start mb-4">
                <span className="text-xs font-bold bg-success-50 text-success-700 border border-success-200 px-2.5 py-1 rounded-full">
                  {t.stat}
                </span>
              </div>

              {/* Quote */}
              <p className="text-surface-600 text-sm leading-relaxed flex-1 mb-6">
                &ldquo;{t.quote}&rdquo;
              </p>

              {/* Author */}
              <div className="flex items-center gap-3 pt-4 border-t border-surface-100">
                <div className="w-10 h-10 rounded-full bg-brand-100 flex items-center justify-center text-brand-700 font-bold text-sm shrink-0">
                  {t.avatar}
                </div>
                <div>
                  <p className="font-semibold text-surface-800 text-sm">{t.author}</p>
                  <p className="text-xs text-surface-400">{t.role}</p>
                </div>
                <span className="ml-auto text-xs text-surface-300 bg-surface-50 border border-surface-200 px-2 py-0.5 rounded-full whitespace-nowrap">
                  {t.industry}
                </span>
              </div>
            </div>
          ))}
        </div>

        {/* Trust bar */}
        <div className="mt-14 grid grid-cols-2 sm:grid-cols-4 gap-6 border-t border-surface-100 pt-12">
          {[
            { value: '10,000+', label: 'Active businesses' },
            { value: '2.4M+',   label: 'Chats handled' },
            { value: '4.9/5',   label: 'Average rating' },
            { value: '98%',     label: 'Would recommend' },
          ].map(s => (
            <div key={s.label} className="text-center">
              <div className="text-3xl font-black text-surface-900 mb-1">{s.value}</div>
              <div className="text-sm text-surface-400">{s.label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
