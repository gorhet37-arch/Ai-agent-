import { Code2, Settings, TrendingUp, ArrowRight } from 'lucide-react'

const steps = [
  {
    num: '01',
    icon: Settings,
    title: 'Set up in 5 minutes',
    desc: 'Create an account, add your business info, services, and hours. Your AI learns everything about your business instantly.',
    note: 'No technical skills required',
    color: 'text-brand-600',
    bg: 'bg-brand-50',
    border: 'border-brand-100',
  },
  {
    num: '02',
    icon: Code2,
    title: 'Add one line of code',
    desc: 'Copy the embed snippet from your dashboard and paste it into your website. Works with every website builder and CMS.',
    note: 'WordPress, Wix, Webflow & more',
    color: 'text-accent-600',
    bg: 'bg-accent-50',
    border: 'border-accent-100',
  },
  {
    num: '03',
    icon: TrendingUp,
    title: 'Watch leads roll in',
    desc: 'Your AI starts working immediately. Every visitor gets answered, every lead gets captured — straight into your dashboard.',
    note: 'Leads scored hot, warm, or cold',
    color: 'text-success-600',
    bg: 'bg-success-50',
    border: 'border-success-100',
  },
]

export default function HowItWorks() {
  return (
    <section id="how-it-works" className="py-24 bg-surface-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 bg-white border border-surface-200 text-surface-600 rounded-full px-4 py-2 mb-5 text-sm font-semibold shadow-card">
            Dead simple setup
          </div>
          <h2 className="text-4xl lg:text-5xl font-bold text-surface-900 mb-4">
            Up and running in 5 minutes
          </h2>
          <p className="text-xl text-surface-500 max-w-2xl mx-auto">
            No developers, no integrations, no complicated setup.
            Just three steps between you and a 24/7 AI receptionist.
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8 items-start">
          {steps.map((step, i) => (
            <div key={step.num} className="relative">
              {/* Connector arrow */}
              {i < steps.length - 1 && (
                <div className="hidden lg:flex absolute -right-4 top-12 z-10 items-center">
                  <ArrowRight className="w-6 h-6 text-surface-300" />
                </div>
              )}
              <div className={`card p-8 border-2 ${step.border} hover:shadow-card-hover transition-all duration-300`}>
                <div className="flex items-start justify-between mb-6">
                  <div className={`w-12 h-12 rounded-xl ${step.bg} flex items-center justify-center`}>
                    <step.icon className={`w-6 h-6 ${step.color}`} />
                  </div>
                  <span className="text-5xl font-black text-surface-100 leading-none">{step.num}</span>
                </div>
                <h3 className="text-xl font-bold text-surface-900 mb-3">{step.title}</h3>
                <p className="text-surface-500 leading-relaxed text-sm mb-4">{step.desc}</p>
                <div className={`inline-flex items-center gap-1.5 text-xs font-semibold ${step.color} ${step.bg} px-3 py-1.5 rounded-full`}>
                  ✓ {step.note}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
