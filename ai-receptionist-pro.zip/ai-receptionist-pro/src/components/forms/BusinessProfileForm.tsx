'use client'
import { useState, useEffect } from 'react'
import toast from 'react-hot-toast'
import {
  Loader2, Plus, Trash2, Save, Settings, Clock, List,
  HelpCircle, Palette, Copy, Check, ExternalLink, Bot
} from 'lucide-react'
import { cn } from '@/lib/utils'
import type { BusinessProfile } from '@/types'
import Link from 'next/link'

interface Props { profile: BusinessProfile | null; isLoading?: boolean }

interface FormData {
  business_name: string; industry: string; phone: string; email: string
  website: string; address: string; city: string; state: string; zip: string
  description: string; timezone: string; ai_persona_name: string
  custom_greeting: string; widget_color: string
  widget_position: 'bottom-right' | 'bottom-left'
  business_hours: Record<string, { open: boolean; start: string; end: string }>
  services: Array<{ id: string; name: string; description: string; duration: number; price: number | null }>
  faqs: Array<{ id: string; question: string; answer: string }>
}

const INDUSTRIES = [
  ['dental','Dental / Dentistry'],['real_estate','Real Estate'],['law_firm','Law Firm'],
  ['plumbing','Plumbing'],['hvac','HVAC / Heating & Cooling'],['roofing','Roofing'],
  ['medical','Medical / Healthcare'],['insurance','Insurance'],['salon','Salon / Beauty'],
  ['auto_repair','Auto Repair'],['landscaping','Landscaping'],['cleaning','Cleaning Services'],
  ['other','Other'],
]
const TIMEZONES = [
  'America/New_York','America/Chicago','America/Denver','America/Los_Angeles',
  'America/Phoenix','America/Anchorage','Pacific/Honolulu',
  'Europe/London','Europe/Paris','Europe/Berlin','Australia/Sydney',
]
const DAYS = ['monday','tuesday','wednesday','thursday','friday','saturday','sunday']
const DEFAULT_HOURS: FormData['business_hours'] = Object.fromEntries(
  DAYS.map(d => [d, { open: ['saturday','sunday'].includes(d) ? false : true, start: '09:00', end: '17:00' }])
)
const COLORS = ['#0c7eea','#7c3aed','#16a34a','#dc2626','#d97706','#0891b2','#db2777','#475569']
type Tab = 'basic' | 'hours' | 'services' | 'faqs' | 'widget'

const TABS: { id: Tab; label: string; icon: React.ElementType }[] = [
  { id: 'basic',    label: 'Basic Info',     icon: Settings },
  { id: 'hours',    label: 'Hours',          icon: Clock },
  { id: 'services', label: 'Services',       icon: List },
  { id: 'faqs',     label: 'FAQs',           icon: HelpCircle },
  { id: 'widget',   label: 'Widget',         icon: Palette },
]

export default function BusinessProfileForm({ profile }: Props) {
  const [formData, setFormData] = useState<FormData>({
    business_name: '', industry: 'other', phone: '', email: '', website: '',
    address: '', city: '', state: '', zip: '', description: '',
    timezone: 'America/New_York', ai_persona_name: 'Alex', custom_greeting: '',
    widget_color: '#0c7eea', widget_position: 'bottom-right',
    business_hours: DEFAULT_HOURS, services: [], faqs: [],
  })
  const [submitting, setSubmitting] = useState(false)
  const [activeTab, setActiveTab] = useState<Tab>('basic')
  const [embedCopied, setEmbedCopied] = useState(false)
  const [newService, setNewService] = useState({ name: '', description: '', duration: 60, price: null as number | null })
  const [newFaq, setNewFaq] = useState({ question: '', answer: '' })

  useEffect(() => {
    if (!profile) return
    setFormData({
      business_name:   profile.business_name ?? '',
      industry:        profile.industry ?? 'other',
      phone:           profile.phone ?? '',
      email:           profile.email ?? '',
      website:         profile.website ?? '',
      address:         profile.address ?? '',
      city:            profile.city ?? '',
      state:           profile.state ?? '',
      zip:             profile.zip ?? '',
      description:     profile.description ?? '',
      timezone:        profile.timezone ?? 'America/New_York',
      ai_persona_name: profile.ai_persona_name ?? 'Alex',
      custom_greeting: profile.custom_greeting ?? '',
      widget_color:    profile.widget_color ?? '#0c7eea',
      widget_position: (profile.widget_position as 'bottom-right' | 'bottom-left') ?? 'bottom-right',
      business_hours:  (profile.business_hours && Object.keys(profile.business_hours).length > 0) ? (profile.business_hours as unknown as FormData['business_hours']) : DEFAULT_HOURS,
      services:        (profile.services ?? []) as FormData['services'],
      faqs:            (profile.faqs ?? []) as FormData['faqs'],
    })
  }, [profile])

  const set = (key: keyof FormData, val: unknown) =>
    setFormData(prev => ({ ...prev, [key]: val }))

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!formData.business_name.trim()) { toast.error('Business name is required'); return }
    setSubmitting(true)
    try {
      const res = await fetch('/api/business/profile', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      })
      if (!res.ok) {
        const err = (await res.json()) as { error?: string }
        toast.error(err.error ?? 'Failed to save profile')
        return
      }
      toast.success('Profile saved successfully!')
    } catch {
      toast.error('Network error — please try again')
    } finally {
      setSubmitting(false)
    }
  }

  const addService = () => {
    if (!newService.name.trim()) { toast.error('Service name is required'); return }
    set('services', [...formData.services, { ...newService, id: crypto.randomUUID() }])
    setNewService({ name: '', description: '', duration: 60, price: null })
  }

  const removeService = (id: string) =>
    set('services', formData.services.filter(s => s.id !== id))

  const addFaq = () => {
    if (!newFaq.question.trim() || !newFaq.answer.trim()) { toast.error('Both question and answer are required'); return }
    set('faqs', [...formData.faqs, { ...newFaq, id: crypto.randomUUID() }])
    setNewFaq({ question: '', answer: '' })
  }

  const removeFaq = (id: string) =>
    set('faqs', formData.faqs.filter(f => f.id !== id))

  const embedCode = profile
    ? `<script src="${typeof window !== 'undefined' ? window.location.origin : ''}/embed.js" data-business-id="${profile.id}" defer></script>`
    : ''

  const copyEmbed = () => {
    navigator.clipboard.writeText(embedCode).then(() => {
      setEmbedCopied(true)
      setTimeout(() => setEmbedCopied(false), 2000)
    })
  }

  return (
    <form onSubmit={handleSubmit}>
      {/* Tab bar */}
      <div className="flex overflow-x-auto border-b border-surface-100 bg-surface-50 px-4 gap-1 scrollbar-none">
        {TABS.map(tab => (
          <button key={tab.id} type="button"
            onClick={() => setActiveTab(tab.id)}
            className={cn(
              'flex items-center gap-2 px-4 py-3.5 text-sm font-medium whitespace-nowrap border-b-2 transition-all -mb-px',
              activeTab === tab.id
                ? 'border-brand-600 text-brand-700'
                : 'border-transparent text-surface-500 hover:text-surface-800 hover:border-surface-300'
            )}
          >
            <tab.icon className="w-3.5 h-3.5" />
            {tab.label}
          </button>
        ))}
      </div>

      <div className="p-6 space-y-6">

        {/* ── BASIC INFO ── */}
        {activeTab === 'basic' && (
          <div className="space-y-5">
            <div className="grid sm:grid-cols-2 gap-4">
              <div className="sm:col-span-2">
                <label className="label">Business Name <span className="text-danger-500">*</span></label>
                <input className="input" placeholder="e.g. Bright Smile Dental"
                  value={formData.business_name} onChange={e => set('business_name', e.target.value)} required />
              </div>
              <div>
                <label className="label">Industry</label>
                <select className="select" value={formData.industry} onChange={e => set('industry', e.target.value)}>
                  {INDUSTRIES.map(([val, label]) => <option key={val} value={val}>{label}</option>)}
                </select>
              </div>
              <div>
                <label className="label">Timezone</label>
                <select className="select" value={formData.timezone} onChange={e => set('timezone', e.target.value)}>
                  {TIMEZONES.map(tz => <option key={tz} value={tz}>{tz.replace('_', ' ')}</option>)}
                </select>
              </div>
              <div>
                <label className="label">Phone</label>
                <input className="input" placeholder="+1 (555) 000-0000" type="tel"
                  value={formData.phone} onChange={e => set('phone', e.target.value)} />
              </div>
              <div>
                <label className="label">Business Email</label>
                <input className="input" placeholder="contact@business.com" type="email"
                  value={formData.email} onChange={e => set('email', e.target.value)} />
              </div>
              <div className="sm:col-span-2">
                <label className="label">Website</label>
                <input className="input" placeholder="https://yourbusiness.com" type="url"
                  value={formData.website} onChange={e => set('website', e.target.value)} />
              </div>
              <div className="sm:col-span-2">
                <label className="label">Street Address</label>
                <input className="input" placeholder="123 Main Street"
                  value={formData.address} onChange={e => set('address', e.target.value)} />
              </div>
              <div>
                <label className="label">City</label>
                <input className="input" placeholder="New York"
                  value={formData.city} onChange={e => set('city', e.target.value)} />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="label">State</label>
                  <input className="input" placeholder="NY" maxLength={2}
                    value={formData.state} onChange={e => set('state', e.target.value)} />
                </div>
                <div>
                  <label className="label">ZIP</label>
                  <input className="input" placeholder="10001"
                    value={formData.zip} onChange={e => set('zip', e.target.value)} />
                </div>
              </div>
              <div className="sm:col-span-2">
                <label className="label">Business Description</label>
                <textarea className="textarea" rows={3}
                  placeholder="Briefly describe what your business does and who you serve..."
                  value={formData.description} onChange={e => set('description', e.target.value)} />
                <p className="text-xs text-surface-400 mt-1">Used by AI to answer general questions</p>
              </div>
            </div>
          </div>
        )}

        {/* ── HOURS ── */}
        {activeTab === 'hours' && (
          <div className="space-y-3">
            <p className="text-sm text-surface-500">Set when your business is open. The AI will mention these hours to visitors.</p>
            <div className="rounded-xl border border-surface-200 divide-y divide-surface-100 overflow-hidden">
              {DAYS.map(day => {
                const h = formData.business_hours[day] ?? { open: false, start: '09:00', end: '17:00' }
                return (
                  <div key={day} className="flex items-center gap-4 px-4 py-3 bg-white">
                    <div className="w-28 shrink-0">
                      <span className="text-sm font-medium text-surface-700 capitalize">{day}</span>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer shrink-0">
                      <input type="checkbox" className="sr-only peer" checked={h.open}
                        onChange={e => set('business_hours', { ...formData.business_hours, [day]: { ...h, open: e.target.checked } })} />
                      <div className="w-9 h-5 bg-surface-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:bg-brand-600 after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-4 after:w-4 after:transition-all" />
                    </label>
                    {h.open ? (
                      <div className="flex items-center gap-2 flex-1">
                        <input type="time" className="input py-1.5 text-sm w-28"
                          value={h.start} onChange={e => set('business_hours', { ...formData.business_hours, [day]: { ...h, start: e.target.value } })} />
                        <span className="text-surface-400 text-sm">to</span>
                        <input type="time" className="input py-1.5 text-sm w-28"
                          value={h.end} onChange={e => set('business_hours', { ...formData.business_hours, [day]: { ...h, end: e.target.value } })} />
                      </div>
                    ) : (
                      <span className="text-sm text-surface-400 flex-1">Closed</span>
                    )}
                  </div>
                )
              })}
            </div>
          </div>
        )}

        {/* ── SERVICES ── */}
        {activeTab === 'services' && (
          <div className="space-y-5">
            <p className="text-sm text-surface-500">List services you offer. The AI uses these to answer pricing and availability questions.</p>

            {formData.services.length === 0 ? (
              <div className="border-2 border-dashed border-surface-200 rounded-xl p-8 text-center">
                <List className="w-8 h-8 text-surface-300 mx-auto mb-2" />
                <p className="text-sm text-surface-400">No services added yet</p>
              </div>
            ) : (
              <div className="space-y-3">
                {formData.services.map(svc => (
                  <div key={svc.id} className="flex items-start gap-3 p-4 bg-surface-50 border border-surface-200 rounded-xl">
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold text-surface-800 text-sm">{svc.name}</p>
                      {svc.description && <p className="text-xs text-surface-500 mt-0.5">{svc.description}</p>}
                      <div className="flex gap-3 mt-1 text-xs text-surface-400">
                        {svc.duration && <span>{svc.duration} min</span>}
                        {svc.price != null && <span>${svc.price}</span>}
                      </div>
                    </div>
                    <button type="button" onClick={() => removeService(svc.id)}
                      className="p-1.5 text-danger-400 hover:text-danger-600 hover:bg-danger-50 rounded-lg transition-colors shrink-0">
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            )}

            {/* Add new service */}
            <div className="border border-surface-200 rounded-xl p-4 bg-white space-y-3">
              <p className="text-sm font-semibold text-surface-700">Add a Service</p>
              <div className="grid sm:grid-cols-2 gap-3">
                <div className="sm:col-span-2">
                  <label className="label">Service Name</label>
                  <input className="input" placeholder="e.g. Teeth Cleaning"
                    value={newService.name} onChange={e => setNewService(prev => ({ ...prev, name: e.target.value }))} />
                </div>
                <div className="sm:col-span-2">
                  <label className="label">Description</label>
                  <input className="input" placeholder="Brief description (optional)"
                    value={newService.description} onChange={e => setNewService(prev => ({ ...prev, description: e.target.value }))} />
                </div>
                <div>
                  <label className="label">Duration (min)</label>
                  <input className="input" type="number" min={5} step={5} placeholder="60"
                    value={newService.duration} onChange={e => setNewService(prev => ({ ...prev, duration: parseInt(e.target.value) || 60 }))} />
                </div>
                <div>
                  <label className="label">Price ($)</label>
                  <input className="input" type="number" min={0} placeholder="Optional"
                    value={newService.price ?? ''} onChange={e => setNewService(prev => ({ ...prev, price: e.target.value ? parseFloat(e.target.value) : null }))} />
                </div>
              </div>
              <button type="button" onClick={addService} className="btn btn-secondary btn-sm gap-2">
                <Plus className="w-4 h-4" /> Add Service
              </button>
            </div>
          </div>
        )}

        {/* ── FAQs ── */}
        {activeTab === 'faqs' && (
          <div className="space-y-5">
            <p className="text-sm text-surface-500">Common questions your AI should answer confidently.</p>
            {formData.faqs.length === 0 ? (
              <div className="border-2 border-dashed border-surface-200 rounded-xl p-8 text-center">
                <HelpCircle className="w-8 h-8 text-surface-300 mx-auto mb-2" />
                <p className="text-sm text-surface-400">No FAQs added yet</p>
              </div>
            ) : (
              <div className="space-y-3">
                {formData.faqs.map(faq => (
                  <div key={faq.id} className="flex items-start gap-3 p-4 bg-surface-50 border border-surface-200 rounded-xl">
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold text-surface-800 text-sm">Q: {faq.question}</p>
                      <p className="text-xs text-surface-500 mt-1">A: {faq.answer}</p>
                    </div>
                    <button type="button" onClick={() => removeFaq(faq.id)}
                      className="p-1.5 text-danger-400 hover:text-danger-600 hover:bg-danger-50 rounded-lg transition-colors shrink-0">
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            )}
            <div className="border border-surface-200 rounded-xl p-4 bg-white space-y-3">
              <p className="text-sm font-semibold text-surface-700">Add a FAQ</p>
              <div>
                <label className="label">Question</label>
                <input className="input" placeholder="e.g. Do you accept insurance?"
                  value={newFaq.question} onChange={e => setNewFaq(prev => ({ ...prev, question: e.target.value }))} />
              </div>
              <div>
                <label className="label">Answer</label>
                <textarea className="textarea" rows={2} placeholder="We accept most major insurance plans..."
                  value={newFaq.answer} onChange={e => setNewFaq(prev => ({ ...prev, answer: e.target.value }))} />
              </div>
              <button type="button" onClick={addFaq} className="btn btn-secondary btn-sm gap-2">
                <Plus className="w-4 h-4" /> Add FAQ
              </button>
            </div>
          </div>
        )}

        {/* ── WIDGET ── */}
        {activeTab === 'widget' && (
          <div className="space-y-6">
            <div className="grid sm:grid-cols-2 gap-5">
              <div>
                <label className="label">AI Persona Name</label>
                <div className="relative">
                  <Bot className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-surface-400" />
                  <input className="input pl-9" placeholder="Alex"
                    value={formData.ai_persona_name} onChange={e => set('ai_persona_name', e.target.value)} />
                </div>
                <p className="text-xs text-surface-400 mt-1">How the AI introduces itself</p>
              </div>
              <div>
                <label className="label">Widget Position</label>
                <select className="select" value={formData.widget_position} onChange={e => set('widget_position', e.target.value as 'bottom-right' | 'bottom-left')}>
                  <option value="bottom-right">Bottom Right</option>
                  <option value="bottom-left">Bottom Left</option>
                </select>
              </div>
              <div className="sm:col-span-2">
                <label className="label">Custom Greeting Message</label>
                <textarea className="textarea" rows={2}
                  placeholder="Hi! I'm Alex, your virtual assistant. How can I help you today?"
                  value={formData.custom_greeting} onChange={e => set('custom_greeting', e.target.value)} />
              </div>
            </div>

            {/* Colour picker */}
            <div>
              <label className="label">Widget Colour</label>
              <div className="flex items-center gap-3 flex-wrap">
                {COLORS.map(color => (
                  <button key={color} type="button"
                    onClick={() => set('widget_color', color)}
                    className={cn(
                      'w-9 h-9 rounded-full transition-all border-2',
                      formData.widget_color === color ? 'border-surface-900 scale-110 shadow-md' : 'border-transparent hover:scale-105'
                    )}
                    style={{ background: color }}
                  />
                ))}
                <input type="color" className="w-9 h-9 rounded-full cursor-pointer border-0 p-0 bg-transparent"
                  value={formData.widget_color} onChange={e => set('widget_color', e.target.value)}
                  title="Custom colour" />
                <span className="text-sm text-surface-500 font-mono">{formData.widget_color}</span>
              </div>
            </div>

            {/* Preview + Embed code */}
            {profile && (
              <div className="space-y-4">
                {/* Embed code */}
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <label className="label mb-0">Embed Code</label>
                    <div className="flex gap-2">
                      <Link href={`/widget/${profile.id}`} target="_blank"
                        className="btn btn-secondary btn-sm gap-1.5">
                        <ExternalLink className="w-3.5 h-3.5" /> Preview
                      </Link>
                      <button type="button" onClick={copyEmbed}
                        className="btn btn-secondary btn-sm gap-1.5">
                        {embedCopied ? <Check className="w-3.5 h-3.5 text-success-500" /> : <Copy className="w-3.5 h-3.5" />}
                        {embedCopied ? 'Copied!' : 'Copy'}
                      </button>
                    </div>
                  </div>
                  <div className="bg-surface-900 rounded-xl p-4 font-mono text-xs text-success-400 overflow-x-auto">
                    <code>{embedCode}</code>
                  </div>
                  <p className="text-xs text-surface-400 mt-2">
                    Paste this before the <code className="bg-surface-100 px-1 py-0.5 rounded text-surface-600">&lt;/body&gt;</code> tag of any page on your website.
                  </p>
                </div>

                {/* Widget preview */}
                <div className="border border-surface-200 rounded-xl p-4 bg-surface-50">
                  <p className="text-xs font-semibold text-surface-500 uppercase tracking-wider mb-3">Preview</p>
                  <div className="flex items-end justify-end h-24 relative">
                    <div className="flex items-center gap-2 bg-white border border-surface-200 rounded-full px-4 py-2 shadow-card-hover">
                      <div className="w-7 h-7 rounded-full flex items-center justify-center"
                           style={{ background: formData.widget_color }}>
                        <Bot className="w-4 h-4 text-white" />
                      </div>
                      <span className="text-sm font-medium text-surface-700">Chat with {formData.ai_persona_name || 'Alex'}</span>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {!profile && (
              <div className="bg-brand-50 border border-brand-100 rounded-xl p-4 text-sm text-brand-700">
                💡 Save your profile first to generate the embed code for your website.
              </div>
            )}
          </div>
        )}

        {/* Save button */}
        <div className="flex items-center justify-between pt-4 border-t border-surface-100">
          <p className="text-xs text-surface-400">
            {profile ? 'Changes are saved immediately' : 'Fill in basic info to activate your widget'}
          </p>
          <button type="submit" disabled={submitting} className="btn btn-primary btn-md gap-2">
            {submitting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
            {profile ? 'Save Changes' : 'Create Profile'}
          </button>
        </div>
      </div>
    </form>
  )
}
