'use client'
// ============================================
// CHAT WIDGET COMPONENT
// ============================================
// Self-contained floating chat widget. Receives config from parent (widget page).
// Manages its own state: open/close, message list, typing indicator, visitor ID.
//
// Design decisions:
// - visitor_id generated once per session and stored in sessionStorage
// - conversation_id persisted in sessionStorage so refreshing resumes chat
// - Messages stored in component state (not persisted client-side beyond session)
// - All API calls go to /api/chat
// - Color is driven by the business's widget_color field
// ============================================
import { useState, useEffect, useRef, useCallback } from 'react'
import { MessageSquare, X, Send, Loader2, Bot, ChevronDown } from 'lucide-react'
import DOMPurify from 'dompurify'

// ─── Types ────────────────────────────────────────────────────────────────────

interface WidgetMessage {
  id: string
  role: 'user' | 'assistant'
  content: string
  timestamp: Date
}

export interface ChatConfig {
  business_id: string
  business_name: string
  ai_persona_name: string
  custom_greeting: string | null
  primary_color: string   // hex e.g. '#0c7eea'
  position: 'bottom-right' | 'bottom-left'
}

interface ChatWidgetProps {
  config: ChatConfig
  /** When true, renders inline (used in the /widget/[id] preview page) */
  preview?: boolean
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

function generateId(): string {
  return Math.random().toString(36).slice(2) + Date.now().toString(36)
}

function getOrCreateVisitorId(businessId: string): string {
  const key = `visitor_id_${businessId}`
  let id = sessionStorage.getItem(key)
  if (!id) {
    id = `v_${generateId()}`
    sessionStorage.setItem(key, id)
  }
  return id
}

function getStoredConversationId(businessId: string): string | null {
  return sessionStorage.getItem(`conv_id_${businessId}`)
}

function storeConversationId(businessId: string, convId: string) {
  sessionStorage.setItem(`conv_id_${businessId}`, convId)
}

// ─── TypingDots sub-component ─────────────────────────────────────────────────

function TypingDots() {
  return (
    <div className="flex items-center gap-1 px-4 py-3">
      {[0, 1, 2].map(i => (
        <span
          key={i}
          className="w-2 h-2 rounded-full bg-current opacity-60 animate-bounce"
          style={{ animationDelay: `${i * 150}ms` }}
        />
      ))}
    </div>
  )
}

// ─── Main Widget ──────────────────────────────────────────────────────────────

export default function ChatWidget({ config, preview = false }: ChatWidgetProps) {
  const [isOpen, setIsOpen] = useState(preview)
  const [messages, setMessages] = useState<WidgetMessage[]>([])
  const [inputValue, setInputValue] = useState('')
  const [isLoading, setIsLoading] = useState(false)
  const [hasNewMessage, setHasNewMessage] = useState(false)
  const [conversationId, setConversationId] = useState<string | null>(null)
  const [visitorId, setVisitorId] = useState<string>('')
  const [error, setError] = useState<string | null>(null)
  const [hasStarted, setHasStarted] = useState(false)

  const messagesEndRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLInputElement>(null)

  const { primary_color, position, business_name, ai_persona_name, custom_greeting } = config

  // ── Init visitor/conversation IDs from sessionStorage ─────────────────────
  useEffect(() => {
    const vid = getOrCreateVisitorId(config.business_id)
    const cid = getStoredConversationId(config.business_id)
    setVisitorId(vid)
    if (cid) setConversationId(cid)
  }, [config.business_id])

  // ── Greeting message on first open ────────────────────────────────────────
  useEffect(() => {
    if (isOpen && messages.length === 0 && !hasStarted) {
      const greeting = custom_greeting ||
        `Hi there! 👋 I'm ${ai_persona_name}, the virtual receptionist for ${business_name}. How can I help you today?`
      setMessages([{
        id: generateId(),
        role: 'assistant',
        content: greeting,
        timestamp: new Date(),
      }])
      setHasStarted(true)
    }
  }, [isOpen, messages.length, hasStarted, custom_greeting, ai_persona_name, business_name])

  // ── Auto-scroll to bottom ─────────────────────────────────────────────────
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages, isLoading])

  // ── Focus input when opened ───────────────────────────────────────────────
  useEffect(() => {
    if (isOpen) {
      setTimeout(() => inputRef.current?.focus(), 100)
      setHasNewMessage(false)
    }
  }, [isOpen])

  // ── Send message ──────────────────────────────────────────────────────────
  const sendMessage = useCallback(async () => {
    const text = inputValue.trim()
    if (!text || isLoading || !visitorId) return

    setInputValue('')
    setError(null)

    const userMsg: WidgetMessage = {
      id: generateId(),
      role: 'user',
      content: text,
      timestamp: new Date(),
    }
    setMessages(prev => [...prev, userMsg])
    setIsLoading(true)

    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          business_id:     config.business_id,
          visitor_id:      visitorId,
          message:         text,
          conversation_id: conversationId,
        }),
      })

      const data = await res.json() as { reply?: string; conversation_id?: string; error?: string }

      if (!res.ok) {
        throw new Error(data.error || `Server error ${res.status}`)
      }

      if (data.conversation_id) {
        setConversationId(data.conversation_id)
        storeConversationId(config.business_id, data.conversation_id)
      }

      const botMsg: WidgetMessage = {
        id: generateId(),
        role: 'assistant',
        content: data.reply ?? 'Sorry, I had trouble with that. Could you try again?',
        timestamp: new Date(),
      }
      setMessages(prev => [...prev, botMsg])

      if (!isOpen) setHasNewMessage(true)
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Something went wrong'
      setError(message)
      setMessages(prev => [...prev, {
        id: generateId(),
        role: 'assistant',
        content: "I'm having a technical issue right now. Please call us directly or try again in a moment.",
        timestamp: new Date(),
      }])
    } finally {
      setIsLoading(false)
    }
  }, [inputValue, isLoading, visitorId, conversationId, config.business_id, isOpen])

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      sendMessage()
    }
  }

  // ── CSS variables for brand color ─────────────────────────────────────────
  const colorVars = {
    '--widget-color':       primary_color,
    '--widget-color-light': `${primary_color}18`,  // 10% opacity
    '--widget-color-mid':   `${primary_color}33`,  // 20% opacity
  } as React.CSSProperties

  const positionClass = position === 'bottom-left'
    ? 'bottom-5 left-5'
    : 'bottom-5 right-5'

  // ── Render ────────────────────────────────────────────────────────────────
  return (
    <div
      className={preview ? 'relative w-full h-full' : `fixed ${positionClass} z-[9999]`}
      style={colorVars}
    >
      {/* ── Chat panel ── */}
      {isOpen && (
        <div
          className={
            preview
              ? 'w-full h-full flex flex-col bg-white rounded-2xl shadow-2xl overflow-hidden border border-slate-200'
              : 'absolute bottom-16 right-0 w-[380px] max-w-[calc(100vw-2.5rem)] h-[560px] ' +
                'flex flex-col bg-white rounded-2xl shadow-2xl overflow-hidden border border-slate-100 ' +
                'animate-slide-up'
          }
        >
          {/* Header */}
          <div
            className="flex items-center justify-between px-4 py-3 text-white shrink-0"
            style={{ background: `linear-gradient(135deg, ${primary_color}, ${primary_color}dd)` }}
          >
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-full bg-white/20 flex items-center justify-center">
                <Bot className="w-5 h-5" />
              </div>
              <div>
                <div className="font-semibold text-sm leading-tight">{ai_persona_name}</div>
                <div className="flex items-center gap-1.5 mt-0.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-green-300 animate-pulse" />
                  <span className="text-white/80 text-xs">Online · AI Receptionist</span>
                </div>
              </div>
            </div>
            {!preview && (
              <button
                onClick={() => setIsOpen(false)}
                className="w-7 h-7 rounded-full bg-white/20 hover:bg-white/30 flex items-center
                           justify-center transition-colors"
                aria-label="Close chat"
              >
                <ChevronDown className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto px-4 py-4 space-y-3 bg-slate-50">
            {messages.map(msg => (
              <div
                key={msg.id}
                className={`flex gap-2 ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                {msg.role === 'assistant' && (
                  <div
                    className="w-7 h-7 rounded-full flex items-center justify-center shrink-0 mt-1 text-white text-xs font-bold"
                    style={{ background: primary_color }}
                  >
                    {ai_persona_name.charAt(0)}
                  </div>
                )}
                <div
                  className={
                    msg.role === 'user'
                      ? 'max-w-[75%] px-4 py-2.5 rounded-2xl rounded-tr-sm text-sm text-white leading-relaxed shadow-sm'
                      : 'max-w-[80%] px-4 py-2.5 rounded-2xl rounded-tl-sm text-sm bg-white text-slate-700 leading-relaxed shadow-sm border border-slate-100'
                  }
                  style={msg.role === 'user' ? { background: primary_color } : undefined}
                >
                  {DOMPurify.sanitize(msg.content, { ALLOWED_TAGS: [] })}
                </div>
              </div>
            ))}

            {isLoading && (
              <div className="flex gap-2 justify-start">
                <div
                  className="w-7 h-7 rounded-full flex items-center justify-center shrink-0 text-white text-xs font-bold"
                  style={{ background: primary_color }}
                >
                  {ai_persona_name.charAt(0)}
                </div>
                <div className="bg-white rounded-2xl rounded-tl-sm shadow-sm border border-slate-100 text-slate-400">
                  <TypingDots />
                </div>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* Error banner */}
          {error && (
            <div className="px-4 py-2 bg-red-50 border-t border-red-100 text-red-600 text-xs">
              {error}
            </div>
          )}

          {/* Input area */}
          <div className="px-3 py-3 bg-white border-t border-slate-100 shrink-0">
            <div className="flex items-center gap-2 bg-slate-50 rounded-xl border border-slate-200
                            focus-within:border-blue-300 focus-within:ring-2 focus-within:ring-blue-100
                            transition-all px-3 py-1.5">
              <input
                ref={inputRef}
                type="text"
                value={inputValue}
                onChange={e => setInputValue(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Type a message..."
                className="flex-1 bg-transparent text-sm text-slate-800 placeholder:text-slate-400
                           outline-none py-1"
                disabled={isLoading}
                maxLength={2000}
                autoComplete="off"
              />
              <button
                onClick={sendMessage}
                disabled={!inputValue.trim() || isLoading}
                className="w-8 h-8 rounded-lg flex items-center justify-center text-white
                           disabled:opacity-40 transition-all active:scale-95 shrink-0"
                style={{ background: primary_color }}
                aria-label="Send message"
              >
                {isLoading
                  ? <Loader2 className="w-4 h-4 animate-spin" />
                  : <Send className="w-3.5 h-3.5" />
                }
              </button>
            </div>
            <p className="text-center text-[10px] text-slate-400 mt-2">
              Powered by AI Receptionist Pro
            </p>
          </div>
        </div>
      )}

      {/* ── Launcher button ── */}
      {!preview && (
        <button
          onClick={() => setIsOpen(o => !o)}
          className="w-14 h-14 rounded-full text-white shadow-xl hover:shadow-2xl
                     flex items-center justify-center transition-all duration-200
                     active:scale-95 hover:scale-105 relative"
          style={{ background: `linear-gradient(135deg, ${primary_color}, ${primary_color}cc)` }}
          aria-label={isOpen ? 'Close chat' : 'Open chat'}
        >
          {isOpen
            ? <X className="w-6 h-6" />
            : <MessageSquare className="w-6 h-6" />
          }
          {/* New message badge */}
          {hasNewMessage && !isOpen && (
            <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 rounded-full
                             flex items-center justify-center text-[9px] font-bold">
              !
            </span>
          )}
        </button>
      )}
    </div>
  )
}
