'use client'
import { useState } from 'react'
import Link from 'next/link'
import { Bell, Search, ExternalLink, Settings, LogOut, User, ChevronDown } from 'lucide-react'
import { getInitials } from '@/lib/utils'
import { createClient } from '@/lib/supabase'
import { useRouter } from 'next/navigation'

interface TopbarProps {
  user: { full_name: string | null; email: string } | null
  business: { id: string; business_name: string } | null
  unreadNotifications: number
}

export default function DashboardTopbar({ user, business, unreadNotifications }: TopbarProps) {
  const [profileOpen, setProfileOpen] = useState(false)
  const router = useRouter()

  const handleLogout = async () => {
    const supabase = createClient()
    await supabase.auth.signOut()
    router.push('/')
  }

  return (
    <header className="h-16 bg-white border-b border-surface-100 flex items-center justify-between px-4 lg:px-6 shrink-0 gap-4">
      {/* Left: Search (desktop) */}
      <div className="flex-1 max-w-xs hidden md:block">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-surface-400" />
          <input
            type="text"
            placeholder="Search..."
            className="input pl-9 py-2 text-sm h-9 bg-surface-50 border-surface-200"
            readOnly
          />
        </div>
      </div>

      {/* Right: widget link + notifications + profile */}
      <div className="flex items-center gap-2 ml-auto">
        {business && (
          <Link href={`/widget/${business.id}`} target="_blank"
            className="hidden sm:flex items-center gap-2 text-xs font-medium text-brand-600
                       border border-brand-100 bg-brand-50 hover:bg-brand-100 px-3 py-1.5 rounded-lg transition-colors">
            <div className="w-2 h-2 rounded-full bg-success-500 animate-pulse" />
            Widget Live
            <ExternalLink className="w-3 h-3" />
          </Link>
        )}

        {/* Notifications */}
        <Link href="/dashboard/notifications"
          className="relative p-2 rounded-lg text-surface-500 hover:bg-surface-100 transition-colors">
          <Bell className="w-5 h-5" />
          {unreadNotifications > 0 && (
            <span className="absolute -top-0.5 -right-0.5 w-4 h-4 bg-danger-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center">
              {unreadNotifications > 9 ? '9+' : unreadNotifications}
            </span>
          )}
        </Link>

        {/* Profile dropdown */}
        <div className="relative">
          <button
            onClick={() => setProfileOpen(!profileOpen)}
            className="flex items-center gap-2 p-1 pr-2 rounded-xl hover:bg-surface-100 transition-colors group"
          >
            <div className="w-8 h-8 rounded-full bg-brand-100 flex items-center justify-center text-brand-700 font-bold text-sm">
              {user ? getInitials(user.full_name || user.email) : '?'}
            </div>
            <div className="hidden sm:block text-left">
              <p className="text-xs font-semibold text-surface-800 leading-tight">
                {user?.full_name || 'Owner'}
              </p>
              <p className="text-[10px] text-surface-400 leading-tight truncate max-w-[120px]">
                {user?.email}
              </p>
            </div>
            <ChevronDown className="w-3.5 h-3.5 text-surface-400 hidden sm:block" />
          </button>

          {profileOpen && (
            <>
              <div className="fixed inset-0 z-30" onClick={() => setProfileOpen(false)} />
              <div className="absolute right-0 top-full mt-2 w-52 bg-white rounded-xl shadow-dropdown border border-surface-100 z-40 py-1 animate-scale-in">
                <div className="px-3 py-2.5 border-b border-surface-100">
                  <p className="text-sm font-semibold text-surface-800 truncate">{user?.full_name || 'Business Owner'}</p>
                  <p className="text-xs text-surface-400 truncate">{user?.email}</p>
                </div>
                <Link href="/dashboard/settings"
                  onClick={() => setProfileOpen(false)}
                  className="flex items-center gap-2.5 px-3 py-2.5 text-sm text-surface-700 hover:bg-surface-50 transition-colors">
                  <Settings className="w-4 h-4 text-surface-400" />
                  Account Settings
                </Link>
                <Link href="/dashboard/settings"
                  onClick={() => setProfileOpen(false)}
                  className="flex items-center gap-2.5 px-3 py-2.5 text-sm text-surface-700 hover:bg-surface-50 transition-colors">
                  <User className="w-4 h-4 text-surface-400" />
                  Profile
                </Link>
                <div className="border-t border-surface-100 mt-1 pt-1">
                  <button onClick={handleLogout}
                    className="w-full flex items-center gap-2.5 px-3 py-2.5 text-sm text-danger-600 hover:bg-danger-50 transition-colors">
                    <LogOut className="w-4 h-4" />
                    Sign Out
                  </button>
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </header>
  )
}
