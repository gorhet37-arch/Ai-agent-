'use client'
import { useState } from 'react'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import {
  Bot, LayoutDashboard, MessageSquare, Users, Calendar,
  Settings, BarChart3, LogOut, ChevronLeft, ChevronRight,
  Zap, X, Menu
} from 'lucide-react'
import { cn, formatChatLimit } from '@/lib/utils'
import { createClient } from '@/lib/supabase'
import { useRouter } from 'next/navigation'

interface SidebarProps {
  user: { full_name: string | null; email: string } | null
  business: { business_name: string } | null
  subscription: { plan: string; chats_used: number; chats_limit: number } | null
  userRole: string
}

const navItems = [
  { href: '/dashboard',               icon: LayoutDashboard, label: 'Overview' },
  { href: '/dashboard/conversations', icon: MessageSquare,   label: 'Conversations' },
  { href: '/dashboard/leads',         icon: Users,           label: 'Leads' },
  { href: '/dashboard/appointments',  icon: Calendar,        label: 'Appointments' },
  { href: '/dashboard/crm',           icon: BarChart3,       label: 'Analytics' },
  { href: '/dashboard/settings',      icon: Settings,        label: 'Settings' },
]

function SidebarContent({
  user, business, subscription, userRole, collapsed,
  onClose
}: SidebarProps & { collapsed: boolean; onClose?: () => void }) {
  const pathname = usePathname()
  const router = useRouter()

  const handleLogout = async () => {
    const supabase = createClient()
    await supabase.auth.signOut()
    router.push('/')
  }

  const chatPercent = subscription
    ? Math.min(Math.round((subscription.chats_used / (subscription.chats_limit || 500)) * 100), 100)
    : 0

  return (
    <div className="flex flex-col h-full">
      {/* Logo */}
      <div className={cn(
        'flex items-center gap-2.5 px-4 py-4 border-b border-surface-100 h-16',
        collapsed && 'justify-center'
      )}>
        <div className="w-8 h-8 rounded-lg bg-brand-600 flex items-center justify-center shrink-0 shadow-glow-sm">
          <Bot className="w-4 h-4 text-white" />
        </div>
        {!collapsed && (
          <span className="font-bold text-surface-900 truncate text-sm">
            AI Receptionist <span className="text-brand-600">Pro</span>
          </span>
        )}
        {onClose && (
          <button onClick={onClose} className="ml-auto p-1 rounded-lg hover:bg-surface-100 text-surface-400">
            <X className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* Business name */}
      {!collapsed && business && (
        <div className="px-4 py-3 border-b border-surface-100">
          <p className="text-[10px] text-surface-400 uppercase tracking-widest mb-0.5">Business</p>
          <p className="text-sm font-semibold text-surface-800 truncate">{business.business_name}</p>
        </div>
      )}

      {/* Navigation */}
      <nav className="flex-1 px-2 py-3 space-y-0.5 overflow-y-auto">
        {navItems.map(item => {
          const isActive = item.href === '/dashboard'
            ? pathname === '/dashboard'
            : pathname.startsWith(item.href)
          return (
            <Link key={item.href} href={item.href}
              className={cn(
                isActive ? 'sidebar-link-active' : 'sidebar-link',
                collapsed && 'justify-center px-2'
              )}
              title={collapsed ? item.label : undefined}
              onClick={onClose}
            >
              <item.icon className="shrink-0" style={{ width: 17, height: 17 }} />
              {!collapsed && <span>{item.label}</span>}
            </Link>
          )
        })}
      </nav>

      {/* Usage bar */}
      {!collapsed && subscription && (
        <div className="px-3 pb-2">
          <div className="bg-surface-50 rounded-xl border border-surface-100 p-3">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-1.5">
                <Zap className="w-3.5 h-3.5 text-brand-500" />
                <span className="text-xs font-semibold text-surface-700 capitalize">{subscription.plan}</span>
              </div>
              <span className="text-[10px] text-surface-400">
                {formatChatLimit(subscription.chats_used, subscription.chats_limit)}
              </span>
            </div>
            <div className="h-1.5 bg-surface-200 rounded-full overflow-hidden">
              <div className={cn(
                'h-full rounded-full transition-all duration-500',
                chatPercent > 80 ? 'bg-danger-500' : chatPercent > 60 ? 'bg-warning-500' : 'bg-brand-500'
              )} style={{ width: `${chatPercent}%` }} />
            </div>
            <p className="text-[10px] text-surface-400 mt-1">chats used this month</p>
          </div>
        </div>
      )}

      {/* User + actions */}
      <div className="border-t border-surface-100 p-2 space-y-0.5">
        {!collapsed && user && (
          <div className="flex items-center gap-2.5 px-2 py-2 rounded-lg">
            <div className="w-7 h-7 rounded-full bg-brand-100 flex items-center justify-center text-brand-700 font-bold text-xs shrink-0">
              {(user.full_name || user.email)[0].toUpperCase()}
            </div>
            <div className="min-w-0">
              <p className="text-xs font-semibold text-surface-800 truncate">{user.full_name || 'Owner'}</p>
              <p className="text-[10px] text-surface-400 truncate">{user.email}</p>
            </div>
          </div>
        )}
        <button onClick={handleLogout}
          className={cn('sidebar-link w-full text-danger-600 hover:bg-danger-50 hover:text-danger-700', collapsed && 'justify-center px-2')}>
          <LogOut className="w-4 h-4 shrink-0" />
          {!collapsed && <span>Sign Out</span>}
        </button>
      </div>
    </div>
  )
}

export default function DashboardSidebar(props: SidebarProps) {
  const [collapsed, setCollapsed] = useState(false)
  const [mobileOpen, setMobileOpen] = useState(false)

  return (
    <>
      {/* Mobile toggle button — rendered inside topbar via CSS */}
      <button
        id="mobile-sidebar-toggle"
        className="lg:hidden fixed bottom-5 left-5 z-40 w-12 h-12 bg-brand-600 text-white rounded-full shadow-glow flex items-center justify-center"
        onClick={() => setMobileOpen(true)}
      >
        <Menu className="w-5 h-5" />
      </button>

      {/* Mobile drawer */}
      {mobileOpen && (
        <div className="lg:hidden fixed inset-0 z-50 flex">
          <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" onClick={() => setMobileOpen(false)} />
          <div className="relative w-72 bg-white h-full shadow-modal flex flex-col animate-slide-in-left">
            <SidebarContent {...props} collapsed={false} onClose={() => setMobileOpen(false)} />
          </div>
        </div>
      )}

      {/* Desktop sidebar */}
      <aside className={cn(
        'hidden lg:flex flex-col bg-white border-r border-surface-100 transition-all duration-300 shrink-0',
        collapsed ? 'w-16' : 'w-64'
      )}>
        <SidebarContent {...props} collapsed={collapsed} />

        {/* Collapse toggle */}
        <div className="border-t border-surface-100 p-2">
          <button
            onClick={() => setCollapsed(!collapsed)}
            className={cn('sidebar-link w-full', collapsed && 'justify-center px-2')}
          >
            {collapsed
              ? <ChevronRight className="w-4 h-4" />
              : <><ChevronLeft className="w-4 h-4" /><span className="text-xs">Collapse</span></>
            }
          </button>
        </div>
      </aside>
    </>
  )
}
