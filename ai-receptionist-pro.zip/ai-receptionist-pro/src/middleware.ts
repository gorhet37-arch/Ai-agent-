// ============================================
// NEXT.JS MIDDLEWARE — AUTH PROTECTION
// Edge Runtime compatible: NO imports from @/lib/supabase.
// @supabase/supabase-js uses Node.js APIs unavailable in the Edge Runtime.
// We use @supabase/ssr directly here — it is fully Edge-compatible.
// ============================================
import { NextRequest, NextResponse } from 'next/server'
import { createServerClient } from '@supabase/ssr'
import type { CookieOptions } from '@supabase/ssr'

// Routes that require authentication
const PROTECTED_ROUTES = ['/dashboard']
// Routes only for unauthenticated users
const AUTH_ROUTES = ['/auth/login', '/auth/register', '/auth/reset-password']

export async function middleware(request: NextRequest) {
  // Build a fresh response that forwards request headers (required by @supabase/ssr)
  let response = NextResponse.next({
    request: { headers: request.headers },
  })

  // Inline the Supabase middleware client using @supabase/ssr only.
  // @supabase/ssr is Edge-compatible; @supabase/supabase-js is NOT.
  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        getAll() {
          return request.cookies.getAll()
        },
        setAll(cookiesToSet: { name: string; value: string; options: CookieOptions }[]) {
          // Write cookies onto the request first…
          cookiesToSet.forEach(({ name, value }) =>
            request.cookies.set(name, value)
          )
          // …then rebuild the response so cookies propagate to the browser.
          response = NextResponse.next({
            request: { headers: request.headers },
          })
          cookiesToSet.forEach(({ name, value, options }) =>
            response.cookies.set(name, value, options)
          )
        },
      },
    }
  )

  // Refresh session if expired — required for Server Component auth to stay in sync.
  const {
    data: { session },
  } = await supabase.auth.getSession()

  const pathname = request.nextUrl.pathname

  // Redirect authenticated users away from auth pages
  if (session && AUTH_ROUTES.some((r) => pathname.startsWith(r))) {
    return NextResponse.redirect(new URL('/dashboard', request.url))
  }

  // Protect dashboard routes — redirect to login if no session
  if (!session && PROTECTED_ROUTES.some((r) => pathname.startsWith(r))) {
    const redirectUrl = new URL('/auth/login', request.url)
    redirectUrl.searchParams.set('redirectTo', pathname)
    return NextResponse.redirect(redirectUrl)
  }

  return response
}

export const config = {
  matcher: [
    // Run on all routes EXCEPT Next.js internals and static files.
    // Excludes: _next/static, _next/image, favicon.ico, public API routes
    // (api/chat and api/widget are public — the widget embed calls them cross-origin).
    '/((?!_next/static|_next/image|favicon.ico|api/chat|api/widget|public).*)',
  ],
}
