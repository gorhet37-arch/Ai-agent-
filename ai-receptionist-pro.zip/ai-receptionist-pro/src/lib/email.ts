// ============================================
// EMAIL NOTIFICATION SERVICE
// ============================================
import nodemailer from 'nodemailer'
import { Lead, Appointment } from '@/types'

const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST,
  port: parseInt(process.env.SMTP_PORT || '587'),
  secure: false,
  auth: {
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASS,
  },
})

const FROM = process.env.EMAIL_FROM || 'AI Receptionist Pro <noreply@aireceptionistpro.com>'

// Shared email wrapper
function emailWrapper(content: string): string {
  return `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; background: #f8fafc; margin: 0; padding: 0; }
    .container { max-width: 560px; margin: 40px auto; background: white; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 24px rgba(0,0,0,0.08); }
    .header { background: linear-gradient(135deg, #005fc8, #0c7eea); padding: 32px; text-align: center; }
    .header h1 { color: white; margin: 0; font-size: 22px; font-weight: 700; }
    .header p { color: rgba(255,255,255,0.8); margin: 8px 0 0; font-size: 14px; }
    .body { padding: 32px; }
    .badge { display: inline-block; padding: 4px 12px; border-radius: 20px; font-size: 12px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px; }
    .badge-hot { background: #fef2f2; color: #dc2626; }
    .badge-warm { background: #fff7ed; color: #ea580c; }
    .badge-cold { background: #eff6ff; color: #2563eb; }
    .info-row { display: flex; align-items: center; gap: 12px; padding: 12px 0; border-bottom: 1px solid #f1f5f9; }
    .info-label { color: #64748b; font-size: 13px; min-width: 100px; }
    .info-value { color: #0f172a; font-size: 14px; font-weight: 500; }
    .btn { display: inline-block; background: #0c7eea; color: white; padding: 12px 24px; border-radius: 8px; text-decoration: none; font-weight: 600; font-size: 14px; }
    .footer { background: #f8fafc; padding: 20px 32px; text-align: center; }
    .footer p { color: #94a3b8; font-size: 12px; margin: 0; }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>🤖 AI Receptionist Pro</h1>
      <p>Automated Notification</p>
    </div>
    <div class="body">${content}</div>
    <div class="footer">
      <p>This is an automated notification from AI Receptionist Pro.<br>
      Manage your notifications in your <a href="${process.env.NEXT_PUBLIC_APP_URL}/dashboard" style="color: #0c7eea;">dashboard</a>.</p>
    </div>
  </div>
</body>
</html>`
}

/**
 * Send new lead notification to business owner
 */
export async function sendNewLeadEmail(toEmail: string, businessName: string, lead: Lead) {
  const content = `
    <h2 style="color: #0f172a; margin-top: 0;">🔥 New Lead Received!</h2>
    <p style="color: #475569;">A new lead has been captured via your AI receptionist at <strong>${businessName}</strong>.</p>
    <span class="badge badge-${lead.score}">${lead.score} lead</span>
    <div style="margin-top: 20px;">
      <div class="info-row"><span class="info-label">Name</span><span class="info-value">${lead.name}</span></div>
      ${lead.email ? `<div class="info-row"><span class="info-label">Email</span><span class="info-value">${lead.email}</span></div>` : ''}
      ${lead.phone ? `<div class="info-row"><span class="info-label">Phone</span><span class="info-value">${lead.phone}</span></div>` : ''}
      ${lead.service_needed ? `<div class="info-row"><span class="info-label">Service</span><span class="info-value">${lead.service_needed}</span></div>` : ''}
      ${lead.preferred_date ? `<div class="info-row"><span class="info-label">Preferred Date</span><span class="info-value">${lead.preferred_date}</span></div>` : ''}
      <div class="info-row"><span class="info-label">Captured At</span><span class="info-value">${new Date(lead.created_at).toLocaleString()}</span></div>
    </div>
    <div style="margin-top: 24px;">
      <a href="${process.env.NEXT_PUBLIC_APP_URL}/dashboard/leads" class="btn">View Lead in CRM →</a>
    </div>
  `

  await transporter.sendMail({
    from: FROM,
    to: toEmail,
    subject: `🔥 New ${lead.score.toUpperCase()} Lead — ${lead.name} | ${businessName}`,
    html: emailWrapper(content),
  })
}

/**
 * Send appointment confirmation to customer
 */
export async function sendAppointmentConfirmationEmail(appointment: Appointment, businessName: string) {
  if (!appointment.customer_email) return

  const content = `
    <h2 style="color: #0f172a; margin-top: 0;">✅ Appointment Confirmed!</h2>
    <p style="color: #475569;">Hi ${appointment.customer_name}, your appointment at <strong>${businessName}</strong> has been confirmed.</p>
    <div style="background: #f0f7ff; border-radius: 8px; padding: 20px; margin: 20px 0;">
      <div class="info-row"><span class="info-label">Service</span><span class="info-value">${appointment.service}</span></div>
      <div class="info-row"><span class="info-label">Date & Time</span><span class="info-value">${new Date(appointment.start_time).toLocaleString()}</span></div>
      ${appointment.notes ? `<div class="info-row"><span class="info-label">Notes</span><span class="info-value">${appointment.notes}</span></div>` : ''}
    </div>
    <p style="color: #64748b; font-size: 13px;">Need to reschedule? Reply to this email or contact us directly.</p>
  `

  await transporter.sendMail({
    from: FROM,
    to: appointment.customer_email,
    subject: `✅ Appointment Confirmed — ${appointment.service} | ${businessName}`,
    html: emailWrapper(content),
  })
}

/**
 * Send appointment booked notification to business owner
 */
export async function sendAppointmentNotificationEmail(
  toEmail: string,
  businessName: string,
  appointment: Appointment
) {
  const content = `
    <h2 style="color: #0f172a; margin-top: 0;">📅 New Appointment Booked!</h2>
    <p style="color: #475569;">A new appointment has been booked via your AI receptionist at <strong>${businessName}</strong>.</p>
    <div style="margin-top: 20px;">
      <div class="info-row"><span class="info-label">Customer</span><span class="info-value">${appointment.customer_name}</span></div>
      ${appointment.customer_email ? `<div class="info-row"><span class="info-label">Email</span><span class="info-value">${appointment.customer_email}</span></div>` : ''}
      ${appointment.customer_phone ? `<div class="info-row"><span class="info-label">Phone</span><span class="info-value">${appointment.customer_phone}</span></div>` : ''}
      <div class="info-row"><span class="info-label">Service</span><span class="info-value">${appointment.service}</span></div>
      <div class="info-row"><span class="info-label">Start Time</span><span class="info-value">${new Date(appointment.start_time).toLocaleString()}</span></div>
    </div>
    <div style="margin-top: 24px;">
      <a href="${process.env.NEXT_PUBLIC_APP_URL}/dashboard/appointments" class="btn">View Appointment →</a>
    </div>
  `

  await transporter.sendMail({
    from: FROM,
    to: toEmail,
    subject: `📅 New Appointment — ${appointment.customer_name} | ${businessName}`,
    html: emailWrapper(content),
  })
}

/**
 * Welcome email after registration
 */
export async function sendWelcomeEmail(toEmail: string, name: string) {
  const content = `
    <h2 style="color: #0f172a; margin-top: 0;">Welcome to AI Receptionist Pro! 🎉</h2>
    <p style="color: #475569;">Hi ${name}, thanks for joining! You're just a few steps away from having an AI receptionist working 24/7 for your business.</p>
    <div style="background: #f0f7ff; border-radius: 8px; padding: 20px; margin: 20px 0;">
      <h3 style="margin-top: 0; color: #0f172a;">Get started in 3 steps:</h3>
      <p style="margin: 8px 0; color: #475569;">1️⃣ <strong>Set up your business profile</strong> — add your services and FAQs</p>
      <p style="margin: 8px 0; color: #475569;">2️⃣ <strong>Customize your AI receptionist</strong> — give it a name and greeting</p>
      <p style="margin: 8px 0; color: #475569;">3️⃣ <strong>Add the chat widget</strong> to your website — one line of code</p>
    </div>
    <a href="${process.env.NEXT_PUBLIC_APP_URL}/dashboard" class="btn">Go to Dashboard →</a>
  `

  await transporter.sendMail({
    from: FROM,
    to: toEmail,
    subject: 'Welcome to AI Receptionist Pro! 🎉',
    html: emailWrapper(content),
  })
}
