// ============================================
// AI ENGINE — OPENAI INTEGRATION
// ============================================
// Bugs fixed from audit:
//   1. JSON.parse(toolCall.function.arguments) — now wrapped in try/catch
//   2. conversationHistory maps all roles as 'user'|'assistant' — system
//      messages are now filtered OUT before mapping (they're not valid history)
//   3. When AI only fires tool_calls, choice.message.content is null — now
//      generates a proper confirmation message from the tool result
//   4. OpenAI client instantiated at module level — moved to factory fn
//      so key is read per-request (supports key rotation without redeploy)
// ============================================
import OpenAI from 'openai'
import { BusinessProfile, Message } from '@/types'

// Factory — reads key per-request so rotation takes effect without redeploy
function getOpenAIClient(): OpenAI {
  const apiKey = process.env.OPENAI_API_KEY
  if (!apiKey) throw new Error('OPENAI_API_KEY environment variable is not set')
  return new OpenAI({ apiKey })
}

// ─── System prompt builder ─────────────────────────────────────────────────────

export function buildSystemPrompt(business: BusinessProfile): string {
  const servicesText = business.services.length
    ? business.services
        .map(
          s =>
            `- ${s.name}: ${s.description}` +
            (s.price != null ? ` ($${s.price})` : '') +
            (s.duration ? ` | ${s.duration} min` : '')
        )
        .join('\n')
    : 'No services listed. Ask the visitor what they need help with.'

  const faqsText = business.faqs.length
    ? business.faqs.map(f => `Q: ${f.question}\nA: ${f.answer}`).join('\n\n')
    : ''

  const hoursText = Object.entries(business.business_hours)
    .map(
      ([day, hours]) =>
        `${day.charAt(0).toUpperCase() + day.slice(1)}: ` +
        (hours.open ? `${hours.start} – ${hours.end}` : 'Closed')
    )
    .join('\n')

  const location = [business.address, business.city, business.state]
    .filter(Boolean)
    .join(', ')

  return `You are ${business.ai_persona_name || 'Alex'}, the AI receptionist for ${business.business_name}.

## Your Role
You are a warm, professional, and efficient AI receptionist. Your goals in priority order:
1. Answer the visitor's question accurately using ONLY the information below
2. Naturally collect their contact details (name, email, phone) during conversation
3. Understand what service they need and when
4. Guide them toward booking — but never pressure

## Business Information
- Name: ${business.business_name}
- Industry: ${business.industry.replace(/_/g, ' ')}
- Phone: ${business.phone || 'Not listed'}
- Email: ${business.email || 'Not listed'}
- Location: ${location || 'Contact us for details'}
- About: ${business.description || `Professional ${business.industry.replace(/_/g, ' ')} services.`}

## Business Hours
${hoursText}

## Services
${servicesText}
${faqsText ? `\n## Frequently Asked Questions\n${faqsText}` : ''}

## Conversation Rules
- Be conversational and concise (under 120 words per reply)
- Use the visitor's name once you learn it
- Never invent facts not listed above — say "I'll have someone follow up on that"
- When you have collected name + email OR name + phone, call save_lead_info immediately
- Do not ask for all contact details at once; collect them naturally over multiple turns
- If they ask to book, collect their preferred date/time and call save_lead_info with that info

## What NOT to do
- Don't repeat the greeting after the first message
- Don't say "As an AI..." or reference your AI nature unless asked
- Don't make up prices, availability, or policies not listed above`.trim()
}

// ─── Main response generator ───────────────────────────────────────────────────

export interface ReceptionistResult {
  response: string
  extractedData: {
    name?: string
    email?: string
    phone?: string
    service?: string
    preferredDate?: string
    shouldCreateLead: boolean
  }
}

export async function generateReceptionistResponse(
  business: BusinessProfile,
  conversationHistory: Message[],
  userMessage: string,
  visitorInfo: { name?: string; email?: string; phone?: string } = {}
): Promise<ReceptionistResult> {
  const openai = getOpenAIClient()
  const systemPrompt = buildSystemPrompt(business)

  // FIX 2: Filter out 'system' role messages — OpenAI only accepts user/assistant
  // in the messages array after the initial system prompt.
  const historyMessages: OpenAI.Chat.ChatCompletionMessageParam[] = conversationHistory
    .filter(m => m.role === 'user' || m.role === 'assistant')
    .slice(-20) // Keep last 20 turns to manage token usage
    .map(m => ({ role: m.role as 'user' | 'assistant', content: m.content }))

  const messages: OpenAI.Chat.ChatCompletionMessageParam[] = [
    { role: 'system', content: systemPrompt },
    ...historyMessages,
    { role: 'user', content: userMessage },
  ]

  const tools: OpenAI.Chat.ChatCompletionTool[] = [
    {
      type: 'function',
      function: {
        name: 'save_lead_info',
        description:
          'Call this whenever you have collected at least the visitor name plus one of: email or phone. Also call it when they express intent to book.',
        parameters: {
          type: 'object',
          properties: {
            name:          { type: 'string', description: 'Full name of the visitor' },
            email:         { type: 'string', description: 'Email address' },
            phone:         { type: 'string', description: 'Phone number' },
            service:       { type: 'string', description: 'Service they are interested in' },
            preferredDate: { type: 'string', description: 'Preferred appointment date/time as described by visitor' },
            notes:         { type: 'string', description: 'Any other relevant notes' },
          },
        },
      },
    },
  ]

  const completion = await openai.chat.completions.create({
    model: process.env.OPENAI_MODEL || 'gpt-4o-mini',
    messages,
    tools,
    tool_choice: 'auto',
    temperature: 0.65,
    max_tokens: 400,
  })

  const choice = completion.choices[0]
  let extractedData: Record<string, string | undefined> = {}
  let shouldCreateLead = false

  // FIX 1: Wrap JSON.parse in try/catch — malformed args must not crash the route
  if (choice.message.tool_calls?.length) {
    for (const toolCall of choice.message.tool_calls) {
      if (toolCall.function.name === 'save_lead_info') {
        try {
          const args = JSON.parse(toolCall.function.arguments) as Record<string, string>
          extractedData = { ...extractedData, ...args }
          shouldCreateLead = true
        } catch (parseErr) {
          console.error('[ai-engine] Failed to parse tool_call arguments:', parseErr)
          // Non-fatal — continue without creating lead
        }
      }
    }
  }

  // FIX 3: When AI fires tool_calls only, content is null.
  // Use the text content if present; otherwise generate a natural reply from what we collected.
  let responseText = choice.message.content

  if (!responseText) {
    if (shouldCreateLead && extractedData.name) {
      responseText =
        `Thanks, ${extractedData.name}! I've noted your details` +
        (extractedData.service ? ` for ${extractedData.service}` : '') +
        '. Someone from our team will be in touch shortly. Is there anything else I can help you with?'
    } else {
      // Fallback: ask a follow-up rather than a confusing generic greeting
      responseText = 'Got it! Is there anything else I can help you with today?'
    }
  }

  return {
    response: responseText,
    extractedData: {
      name:          extractedData.name          || visitorInfo.name,
      email:         extractedData.email         || visitorInfo.email,
      phone:         extractedData.phone         || visitorInfo.phone,
      service:       extractedData.service,
      preferredDate: extractedData.preferredDate || extractedData.startTime,
      shouldCreateLead,
    },
  }
}

// ─── Lead scoring ──────────────────────────────────────────────────────────────

export function calculateLeadScore(data: {
  hasEmail: boolean
  hasPhone: boolean
  hasServiceInterest: boolean
  hasPreferredDate: boolean
  messageCount: number
}): 'hot' | 'warm' | 'cold' {
  let score = 0
  if (data.hasEmail)          score += 2
  if (data.hasPhone)          score += 2
  if (data.hasServiceInterest) score += 2
  if (data.hasPreferredDate)  score += 3
  if (data.messageCount > 4)  score += 1

  if (score >= 7) return 'hot'
  if (score >= 3) return 'warm'
  return 'cold'
}
