// ============================================
// UTILITY FUNCTIONS
// ============================================
import { type ClassValue, clsx } from 'clsx'
import { twMerge } from 'tailwind-merge'
import { format, formatDistanceToNow, isToday, isYesterday } from 'date-fns'
import { LeadScore, SubscriptionPlan } from '@/types'

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function formatDate(date: string | Date, pattern = 'MMM d, yyyy') {
  return format(new Date(date), pattern)
}

export function formatDateTime(date: string | Date) {
  return format(new Date(date), 'MMM d, yyyy h:mm a')
}

export function timeAgo(date: string | Date) {
  const d = new Date(date)
  if (isToday(d)) return formatDistanceToNow(d, { addSuffix: true })
  if (isYesterday(d)) return `Yesterday at ${format(d, 'h:mm a')}`
  return formatDate(d)
}

export function capitalize(str: string) {
  return str.charAt(0).toUpperCase() + str.slice(1)
}

export function formatIndustry(industry: string) {
  return industry.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())
}

export function getLeadScoreColor(score: LeadScore): string {
  const map: Record<LeadScore, string> = {
    hot:  'bg-red-50 text-red-600 border-red-200',
    warm: 'bg-orange-50 text-orange-600 border-orange-200',
    cold: 'bg-blue-50 text-blue-600 border-blue-200',
  }
  return map[score]
}

export function getLeadScoreEmoji(score: LeadScore): string {
  const map: Record<LeadScore, string> = { hot: '🔥', warm: '🌤', cold: '❄️' }
  return map[score]
}

export function getPlanInfo(plan: SubscriptionPlan) {
  const plans: Record<SubscriptionPlan, { name: string; limit: number; color: string; price: number }> = {
    starter:      { name: 'Starter',      limit: 500,      color: 'blue',   price: 29 },
    professional: { name: 'Professional', limit: 2000,     color: 'purple', price: 79 },
    agency:       { name: 'Agency',       limit: Infinity, color: 'gold',   price: 199 },
  }
  return plans[plan]
}

export function formatChatLimit(used: number, limit: number): string {
  if (limit === Infinity || limit === -1) return `${used.toLocaleString()} / ∞`
  return `${used.toLocaleString()} / ${limit.toLocaleString()}`
}

export function generateVisitorId(): string {
  return `visitor_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`
}

export function truncate(str: string, maxLength = 60): string {
  if (str.length <= maxLength) return str
  return str.slice(0, maxLength) + '...'
}

export function getInitials(name: string): string {
  return name
    .split(' ')
    .map(part => part[0])
    .join('')
    .toUpperCase()
    .slice(0, 2)
}

export function isValidEmail(email: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)
}

export function isValidPhone(phone: string): boolean {
  return /^\+?[\d\s\-(]{10,}$/.test(phone)
}

export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(amount)
}

export function formatPercent(value: number, decimals = 1): string {
  return `${value.toFixed(decimals)}%`
}

/** In-memory rate limiter for API routes */
const rateLimitStore = new Map<string, { count: number; resetTime: number }>()

export function checkRateLimit(
  key: string,
  maxRequests = 30,
  windowMs = 60_000
): { allowed: boolean; remaining: number } {
  const now = Date.now()
  const entry = rateLimitStore.get(key)

  if (!entry || now > entry.resetTime) {
    rateLimitStore.set(key, { count: 1, resetTime: now + windowMs })
    return { allowed: true, remaining: maxRequests - 1 }
  }

  if (entry.count >= maxRequests) {
    return { allowed: false, remaining: 0 }
  }

  entry.count++
  return { allowed: true, remaining: maxRequests - entry.count }
}
