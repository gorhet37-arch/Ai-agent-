// ============================================
// SUPABASE CLIENT UTILITIES
// ============================================
// Architecture: This single file serves both client and server contexts.
// next/headers is imported INSIDE the function that needs it (not at module top),
// which prevents the "next/headers in Client Component" error when client
// components import createClient() from this file.
// ============================================
import { createBrowserClient, createServerClient } from '@supabase/ssr'
import { createClient as createSupabaseClient } from '@supabase/supabase-js'
import { NextRequest, NextResponse } from 'next/server'
import type { CookieOptions } from '@supabase/ssr'

const supabaseUrl  = process.env.NEXT_PUBLIC_SUPABASE_URL!
const supabaseAnon = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!

// ─── Browser client (Client Components) ───────────────────────────────────────
// Safe to import in any component — no server-only APIs used.
export function createClient() {
  return createBrowserClient(supabaseUrl, supabaseAnon)
}

// ─── Server client (Server Components, Route Handlers, Server Actions) ─────────
// Import of next/headers is deferred inside the function so that bundler tree-
// shaking can exclude it from client bundles.
export async function createServerSupabaseClient() {
  const { cookies } = await import('next/headers')
  const cookieStore = cookies()

  return createServerClient(supabaseUrl, supabaseAnon, {
    cookies: {
      getAll() {
        return cookieStore.getAll()
      },
      // setAll intentionally omitted — cookie mutations happen in middleware.
      // This client is read-only for session state in Server Components.
    },
  })
}

// ─── Service role client (server-only, never sent to browser) ─────────────────
export function createServiceRoleClient() {
  const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY
  if (!serviceKey) {
    throw new Error('SUPABASE_SERVICE_ROLE_KEY is not set')
  }
  return createSupabaseClient(supabaseUrl, serviceKey, {
    auth: { persistSession: false, autoRefreshToken: false },
  })
}

// ─── Middleware client ─────────────────────────────────────────────────────────
export function createMiddlewareClient(request: NextRequest) {
  let response = NextResponse.next({
    request: { headers: request.headers },
  })

  const supabase = createServerClient(supabaseUrl, supabaseAnon, {
    cookies: {
      getAll() {
        return request.cookies.getAll()
      },
      setAll(cookiesToSet: { name: string; value: string; options: CookieOptions }[]) {
        cookiesToSet.forEach(({ name, value }) => {
          request.cookies.set(name, value)
        })
        response = NextResponse.next({
          request: { headers: request.headers },
        })
        cookiesToSet.forEach(({ name, value, options }) => {
          response.cookies.set(name, value, options)
        })
      },
    },
  })

  return { supabase, response }
}
