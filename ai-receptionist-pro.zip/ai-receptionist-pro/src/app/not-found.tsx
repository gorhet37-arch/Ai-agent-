import Link from 'next/link'
import { Bot, ArrowLeft, Home } from 'lucide-react'

export default function NotFound() {
  return (
    <div className="min-h-screen bg-surface-50 flex items-center justify-center px-4">
      <div className="text-center max-w-md">
        <div className="w-20 h-20 rounded-2xl bg-brand-100 flex items-center justify-center mx-auto mb-6">
          <Bot className="w-10 h-10 text-brand-600" />
        </div>
        <h1 className="text-6xl font-black text-surface-200 mb-2">404</h1>
        <h2 className="text-2xl font-bold text-surface-900 mb-3">Page not found</h2>
        <p className="text-surface-500 text-sm mb-8 leading-relaxed">
          The page you&apos;re looking for doesn&apos;t exist or has been moved.
          Let&apos;s get you back on track.
        </p>
        <div className="flex flex-col sm:flex-row gap-3 justify-center">
          <Link href="/" className="btn btn-primary btn-md gap-2">
            <Home className="w-4 h-4" /> Go Home
          </Link>
          <Link href="/dashboard" className="btn btn-secondary btn-md gap-2">
            <ArrowLeft className="w-4 h-4" /> Dashboard
          </Link>
        </div>
      </div>
    </div>
  )
}
