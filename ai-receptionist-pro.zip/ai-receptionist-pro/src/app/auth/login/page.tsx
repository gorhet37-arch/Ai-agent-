'use client'
// ============================================
// LOGIN PAGE
// ============================================
// FIX 8: useSearchParams() requires a Suspense boundary in App Router.
// This splits into a wrapper with Suspense + the actual login component.
// ============================================
import { Suspense } from 'react'
import LoginForm from './LoginForm'

export default function LoginPage() {
  return (
    <Suspense fallback={<LoginPageSkeleton />}>
      <LoginForm />
    </Suspense>
  )
}

function LoginPageSkeleton() {
  return (
    <div className="w-full max-w-md">
      <div className="bg-white rounded-2xl shadow-2xl p-8 space-y-4 animate-pulse">
        <div className="h-8 bg-surface-200 rounded-lg w-3/4 mx-auto" />
        <div className="h-4 bg-surface-100 rounded-lg w-1/2 mx-auto mt-2" />
        <div className="space-y-4 mt-8">
          <div className="h-10 bg-surface-100 rounded-lg" />
          <div className="h-10 bg-surface-100 rounded-lg" />
          <div className="h-10 bg-surface-100 rounded-lg" />
        </div>
      </div>
    </div>
  )
}
