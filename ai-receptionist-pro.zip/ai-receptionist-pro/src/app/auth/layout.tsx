import Link from 'next/link'
import { Bot } from 'lucide-react'

export default function AuthLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-brand-950 via-brand-900 to-surface-900
                    flex flex-col items-center justify-center p-4 sm:p-6 lg:p-8 relative overflow-hidden">
      {/* Subtle background texture */}
      <div className="absolute inset-0 opacity-[0.04]"
           style={{ backgroundImage: 'linear-gradient(rgba(255,255,255,0.8) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.8) 1px, transparent 1px)', backgroundSize: '48px 48px' }} />
      <div className="absolute inset-0"
           style={{ backgroundImage: 'radial-gradient(ellipse at 30% 20%, rgba(12,126,234,0.25) 0%, transparent 60%), radial-gradient(ellipse at 70% 80%, rgba(195,68,237,0.15) 0%, transparent 60%)' }} />

      {/* Mobile logo */}
      <Link href="/" className="lg:hidden flex items-center gap-2 mb-8 relative z-10">
        <div className="w-9 h-9 rounded-xl bg-brand-600 flex items-center justify-center shadow-glow">
          <Bot className="w-5 h-5 text-white" />
        </div>
        <span className="font-bold text-white text-lg">AI Receptionist <span className="text-brand-300">Pro</span></span>
      </Link>

      <div className="relative z-10 w-full flex items-center justify-center">
        {children}
      </div>

      <p className="relative z-10 text-white/30 text-xs mt-8">
        © {new Date().getFullYear()} AI Receptionist Pro
      </p>
    </div>
  )
}
