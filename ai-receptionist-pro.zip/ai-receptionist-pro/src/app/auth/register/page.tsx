'use client'
import { useState } from 'react'
import Link from 'next/link'
import { createClient } from '@/lib/supabase'
import toast from 'react-hot-toast'
import { Eye, EyeOff, Loader2, Check, Bot, Mail } from 'lucide-react'

const benefits = [
  '14-day free trial — no card needed',
  'Live in under 5 minutes',
  'Cancel anytime, no lock-in',
  'Works on any website',
]

export default function RegisterPage() {
  const [fullName, setFullName] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [showPassword, setShowPassword] = useState(false)
  const [loading, setLoading] = useState(false)
  const [registered, setRegistered] = useState(false)

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault()
    if (password.length < 8) { toast.error('Password must be at least 8 characters'); return }
    setLoading(true)

    try {
      const supabase = createClient()
      const redirectTo = `${window.location.origin}/auth/callback`

      const { error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: { full_name: fullName },
          emailRedirectTo: redirectTo,
        },
      })

      if (error) { toast.error(error.message); return }
      setRegistered(true)
    } catch {
      toast.error('Something went wrong. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  if (registered) {
    return (
      <div className="w-full max-w-md animate-scale-in">
        <div className="bg-white rounded-2xl shadow-modal p-10 text-center">
          <div className="w-20 h-20 bg-success-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <Mail className="w-10 h-10 text-success-600" />
          </div>
          <h1 className="text-2xl font-bold text-surface-900 mb-3">Check your inbox</h1>
          <p className="text-surface-500 text-sm leading-relaxed mb-2">
            We sent a verification link to
          </p>
          <p className="font-semibold text-brand-600 mb-6">{email}</p>
          <p className="text-surface-400 text-xs leading-relaxed mb-8">
            Click the link in the email to verify your account and access your dashboard.
            Check your spam folder if you don&apos;t see it within a few minutes.
          </p>
          <Link href="/auth/login" className="btn btn-primary btn-md w-full justify-center">
            Go to Sign In
          </Link>
          <button
            className="text-xs text-surface-400 hover:text-surface-600 mt-4 block w-full"
            onClick={async () => {
              const supabase = createClient()
              await supabase.auth.resend({ type: 'signup', email })
              toast.success('Verification email resent!')
            }}
          >
            Didn&apos;t receive it? Resend email
          </button>
        </div>
      </div>
    )
  }

  return (
    <div className="w-full max-w-4xl grid lg:grid-cols-2 gap-8 items-center animate-fade-in">
      {/* Left: Benefits */}
      <div className="hidden lg:block">
        <div className="flex items-center gap-2.5 mb-8">
          <div className="w-10 h-10 rounded-xl bg-brand-600 flex items-center justify-center shadow-glow">
            <Bot className="w-5 h-5 text-white" />
          </div>
          <span className="font-bold text-xl text-white">AI Receptionist <span className="text-brand-300">Pro</span></span>
        </div>
        <h2 className="text-3xl font-bold text-white mb-4 leading-tight">
          Start capturing leads<br />while you sleep
        </h2>
        <p className="text-white/60 text-sm leading-relaxed mb-8">
          Join thousands of local businesses using AI to answer questions,
          qualify leads, and book appointments — 24/7.
        </p>
        <div className="space-y-3">
          {benefits.map(b => (
            <div key={b} className="flex items-center gap-3">
              <div className="w-5 h-5 rounded-full bg-success-500/20 border border-success-500/30 flex items-center justify-center shrink-0">
                <Check className="w-3 h-3 text-success-400" />
              </div>
              <span className="text-white/75 text-sm">{b}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Right: Form */}
      <div className="bg-white rounded-2xl shadow-modal p-8">
        <div className="text-center mb-7">
          <h1 className="text-2xl font-bold text-surface-900">Create your account</h1>
          <p className="text-surface-500 text-sm mt-1">Free for 14 days — no credit card</p>
        </div>

        <form onSubmit={handleRegister} className="space-y-4">
          <div>
            <label className="label">Full name</label>
            <input type="text" className="input" placeholder="Jane Smith"
              value={fullName} onChange={e => setFullName(e.target.value)} required />
          </div>
          <div>
            <label className="label">Work email</label>
            <input type="email" className="input" placeholder="you@company.com"
              value={email} onChange={e => setEmail(e.target.value)} required autoComplete="email" />
          </div>
          <div>
            <label className="label">Password</label>
            <div className="relative">
              <input type={showPassword ? 'text' : 'password'} className="input pr-10"
                placeholder="Min. 8 characters" value={password}
                onChange={e => setPassword(e.target.value)} required minLength={8} />
              <button type="button"
                className="absolute right-3 top-1/2 -translate-y-1/2 text-surface-400 hover:text-surface-600"
                onClick={() => setShowPassword(!showPassword)}>
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          <button type="submit" disabled={loading}
            className="btn btn-primary btn-lg w-full justify-center mt-2">
            {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Create Free Account'}
          </button>
        </form>

        <p className="text-center text-xs text-surface-400 mt-4">
          By signing up you agree to our{' '}
          <Link href="#" className="text-brand-600 hover:underline">Terms</Link> &{' '}
          <Link href="#" className="text-brand-600 hover:underline">Privacy Policy</Link>
        </p>
        <p className="text-center text-sm text-surface-500 mt-4">
          Already have an account?{' '}
          <Link href="/auth/login" className="text-brand-600 font-semibold hover:text-brand-700">Sign in</Link>
        </p>
      </div>
    </div>
  )
}
