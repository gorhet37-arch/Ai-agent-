// ============================================
// AUTH CALLBACK ROUTE
// ============================================
// FIX 6: This route MUST exist for email verification to work.
//
// Flow:
//   1. User registers → Supabase sends verification email
//   2. Email link points to: /auth/callback?code=<auth_code>
//   3. This route exchanges the code for a session and sets auth cookies
//   4. User is redirected to dashboard (or /auth/setup if new)
//
// Without this route, clicking "Verify Email" returns a Next.js 404 and
// the user can never complete registration.
// ============================================
import { NextRequest, NextResponse } from 'next/server'
import { createServerClient } from '@supabase/ssr'
import type { CookieOptions } from '@supabase/ssr'

export async function GET(request: NextRequest) {
  const { searchParams, origin } = new URL(request.url)
  const code  = searchParams.get('code')
  const next  = searchParams.get('next') ?? '/dashboard'
  const error = searchParams.get('error')
  const errorDescription = searchParams.get('error_description')

  // Handle Supabase auth errors (expired links, already used, etc.)
  if (error) {
    console.error('[auth/callback] Supabase error:', error, errorDescription)
    const errorUrl = new URL('/auth/login', origin)
    errorUrl.searchParams.set('error', errorDescription ?? error)
    return NextResponse.redirect(errorUrl)
  }

  if (!code) {
    // No code — redirect to login with a message
    const errorUrl = new URL('/auth/login', origin)
    errorUrl.searchParams.set('error', 'Missing verification code. Please try again.')
    return NextResponse.redirect(errorUrl)
  }

  // Build a response we can attach cookies to before redirecting
  const redirectUrl = new URL(next.startsWith('/') ? next : '/dashboard', origin)
  let response = NextResponse.redirect(redirectUrl)

  // Create server client that can write cookies to the response
  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        getAll() {
          return request.cookies.getAll()
        },
        setAll(cookiesToSet: { name: string; value: string; options: CookieOptions }[]) {
          // Write auth cookies to the redirect response so the browser
          // receives the session immediately after email confirmation.
          cookiesToSet.forEach(({ name, value, options }) => {
            response.cookies.set(name, value, options)
          })
        },
      },
    }
  )

  // Exchange the one-time code for a permanent session
  const { error: exchangeError } = await supabase.auth.exchangeCodeForSession(code)

  if (exchangeError) {
    console.error('[auth/callback] Code exchange failed:', exchangeError.message)
    const errorUrl = new URL('/auth/login', origin)
    errorUrl.searchParams.set('error', 'Verification link has expired. Please request a new one.')
    return NextResponse.redirect(errorUrl)
  }

  // Session established — cookies are set on `response`
  // Redirect to dashboard (or whatever `next` param said)
  return response
}
