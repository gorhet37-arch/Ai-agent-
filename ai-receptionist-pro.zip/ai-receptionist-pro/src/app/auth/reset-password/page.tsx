'use client'
import { useState } from 'react'
import Link from 'next/link'
import { createClient } from '@/lib/supabase'
import toast from 'react-hot-toast'
import { Loader2, ArrowLeft, Mail } from 'lucide-react'

export default function ResetPasswordPage() {
  const [email, setEmail] = useState('')
  const [loading, setLoading] = useState(false)
  const [sent, setSent] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    try {
      const supabase = createClient()
      const { error } = await supabase.auth.resetPasswordForEmail(email, {
        redirectTo: `${window.location.origin}/auth/callback?type=recovery`,
      })
      if (error) { toast.error(error.message); return }
      setSent(true)
    } catch {
      toast.error('Something went wrong. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  if (sent) {
    return (
      <div className="w-full max-w-md animate-scale-in">
        <div className="bg-white rounded-2xl shadow-modal p-10 text-center">
          <div className="w-16 h-16 bg-success-100 rounded-full flex items-center justify-center mx-auto mb-5">
            <Mail className="w-8 h-8 text-success-600" />
          </div>
          <h2 className="text-xl font-bold text-surface-900 mb-2">Check your email</h2>
          <p className="text-surface-500 text-sm mb-6">
            We sent a password reset link to <strong>{email}</strong>.
            Click it to set a new password.
          </p>
          <Link href="/auth/login" className="btn btn-secondary btn-md w-full justify-center">
            <ArrowLeft className="w-4 h-4" /> Back to Sign In
          </Link>
        </div>
      </div>
    )
  }

  return (
    <div className="w-full max-w-md animate-fade-in">
      <div className="bg-white rounded-2xl shadow-modal p-8">
        <Link href="/auth/login" className="inline-flex items-center gap-1.5 text-sm text-surface-500 hover:text-surface-800 mb-6">
          <ArrowLeft className="w-4 h-4" /> Back to sign in
        </Link>
        <h1 className="text-2xl font-bold text-surface-900 mb-1">Reset your password</h1>
        <p className="text-surface-500 text-sm mb-6">Enter your email and we&apos;ll send you a reset link.</p>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="label">Email address</label>
            <input type="email" className="input" placeholder="you@company.com"
              value={email} onChange={e => setEmail(e.target.value)} required autoFocus />
          </div>
          <button type="submit" disabled={loading} className="btn btn-primary btn-lg w-full justify-center gap-2">
            {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Send Reset Link'}
          </button>
        </form>
      </div>
    </div>
  )
}
