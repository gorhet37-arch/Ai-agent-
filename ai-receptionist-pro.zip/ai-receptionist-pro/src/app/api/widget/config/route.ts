// ============================================
// API: Widget Configuration
// GET /api/widget/config?business_id=<uuid>
// ============================================
// Returns the configuration needed to render the chat widget.
// Called by the widget page and embed script.
// No authentication required — widget is public-facing.
//
// Response:
//   { business_id, business_name, ai_persona_name, custom_greeting,
//     primary_color, position }
// ============================================
import { NextRequest, NextResponse } from 'next/server'
import { createServiceRoleClient } from '@/lib/supabase'
import type { ChatConfig } from '@/components/chat/ChatWidget'

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url)
  const businessId = searchParams.get('business_id')

  if (!businessId) {
    return NextResponse.json({ error: 'business_id query parameter is required' }, { status: 400 })
  }

  // UUID format check
  const uuidRe = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i
  if (!uuidRe.test(businessId)) {
    return NextResponse.json({ error: 'Invalid business_id format' }, { status: 400 })
  }

  try {
    const supabase = createServiceRoleClient()

    const { data: business, error } = await supabase
      .from('business_profiles')
      .select('id, business_name, ai_persona_name, custom_greeting, widget_color, widget_position, is_active')
      .eq('id', businessId)
      .eq('is_active', true)
      .maybeSingle()

    if (error || !business) {
      return NextResponse.json({ error: 'Business not found' }, { status: 404 })
    }

    const config: ChatConfig = {
      business_id: business.id,
      business_name: business.business_name,
      ai_persona_name: business.ai_persona_name || 'Alex',
      custom_greeting: business.custom_greeting,
      primary_color: business.widget_color || '#0c7eea',
      position: (business.widget_position as 'bottom-right' | 'bottom-left') || 'bottom-right',
    }

    return NextResponse.json(config, {
      headers: {
        'Cache-Control': 'public, s-maxage=300, stale-while-revalidate=3600',
        'Access-Control-Allow-Origin': '*',
      },
    })
  } catch (err) {
    console.error('[api/widget/config] Error:', err)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

// Allow OPTIONS for cross-origin requests from embedded pages
export async function OPTIONS() {
  return new NextResponse(null, {
    headers: {
      'Access-Control-Allow-Origin':  '*',
      'Access-Control-Allow-Methods': 'GET, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type',
    },
  })
}
