// ============================================
// API: Business Profile
// GET  /api/business/profile  — fetch current user's profile
// POST /api/business/profile  — create or update profile
// ============================================
import { NextRequest, NextResponse } from 'next/server'
import { createServerSupabaseClient } from '@/lib/supabase'
import type { ApiResponse, BusinessProfile } from '@/types'

// ── GET: Fetch profile ───────────────────────────────────────────────────────
export async function GET() {
  try {
    const supabase = await createServerSupabaseClient()
    const { data: { session }, error: sessionErr } = await supabase.auth.getSession()

    if (sessionErr || !session?.user) {
      return NextResponse.json({ error: 'Unauthorized' } as ApiResponse, { status: 401 })
    }

    const { data: profile, error } = await supabase
      .from('business_profiles')
      .select('*')
      .eq('user_id', session.user.id)
      .maybeSingle()

    if (error) {
      return NextResponse.json({ error: 'Failed to fetch profile' } as ApiResponse, { status: 500 })
    }

    if (!profile) {
      return NextResponse.json({ error: 'No profile found' } as ApiResponse, { status: 404 })
    }

    return NextResponse.json({ success: true, data: profile } as ApiResponse<BusinessProfile>)
  } catch (err) {
    console.error('[GET /api/business/profile]', err)
    return NextResponse.json({ error: 'Internal server error' } as ApiResponse, { status: 500 })
  }
}

// ── POST: Create or update profile ──────────────────────────────────────────
export async function POST(request: NextRequest) {
  try {
    const supabase = await createServerSupabaseClient()
    const { data: { session }, error: sessionErr } = await supabase.auth.getSession()

    if (sessionErr || !session?.user) {
      return NextResponse.json({ error: 'Unauthorized' } as ApiResponse, { status: 401 })
    }

    const userId = session.user.id
    const body = (await request.json()) as Partial<BusinessProfile>

    if (!body.business_name?.trim()) {
      return NextResponse.json({ error: 'Business name is required' } as ApiResponse, { status: 400 })
    }

    const { data: existing } = await supabase
      .from('business_profiles')
      .select('id')
      .eq('user_id', userId)
      .maybeSingle()

    const profileData = {
      user_id:         userId,
      business_name:   body.business_name?.trim() || '',
      industry:        body.industry || 'other',
      phone:           body.phone || null,
      email:           body.email || null,
      website:         body.website || null,
      address:         body.address || null,
      city:            body.city || null,
      state:           body.state || null,
      zip:             body.zip || null,
      description:     body.description || null,
      timezone:        body.timezone || 'America/New_York',
      business_hours:  body.business_hours || {},
      services:        body.services || [],
      faqs:            body.faqs || [],
      ai_persona_name: body.ai_persona_name || 'Alex',
      custom_greeting: body.custom_greeting || null,
      widget_color:    body.widget_color || '#0c7eea',
      widget_position: body.widget_position || 'bottom-right',
      is_active:       true,
      updated_at:      new Date().toISOString(),
    }

    const result = existing
      ? await supabase.from('business_profiles').update(profileData).eq('user_id', userId).select().single()
      : await supabase.from('business_profiles').insert(profileData).select().single()

    const { data: profile, error } = result

    if (error || !profile) {
      console.error('[POST /api/business/profile] DB error:', error)
      return NextResponse.json({ error: 'Failed to save profile' } as ApiResponse, { status: 500 })
    }

    return NextResponse.json({ success: true, data: profile } as ApiResponse<BusinessProfile>)
  } catch (err) {
    console.error('[POST /api/business/profile]', err)
    return NextResponse.json({ error: 'Internal server error' } as ApiResponse, { status: 500 })
  }
}
