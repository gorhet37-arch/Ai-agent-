// ============================================
// API: Get Current User's Business Profile
// GET /api/business/profile
// ============================================
import { NextResponse } from 'next/server'
import { createServerSupabaseClient } from '@/lib/supabase'
import type { ApiResponse, BusinessProfile } from '@/types'

export async function GET() {
  try {
    const supabase = await createServerSupabaseClient()

    const { data: { session }, error: sessionErr } = await supabase.auth.getSession()

    if (sessionErr || !session?.user) {
      return NextResponse.json(
        { error: 'Unauthorized' } as ApiResponse,
        { status: 401 }
      )
    }

    const { data: profile, error } = await supabase
      .from('business_profiles')
      .select('*')
      .eq('user_id', session.user.id)
      .maybeSingle()

    if (error) {
      return NextResponse.json(
        { error: 'Failed to fetch profile' } as ApiResponse,
        { status: 500 }
      )
    }

    if (!profile) {
      return NextResponse.json(
        { error: 'No profile found' } as ApiResponse,
        { status: 404 }
      )
    }

    return NextResponse.json({ success: true, data: profile } as ApiResponse<BusinessProfile>)
  } catch (err) {
    console.error('[api/business/profile GET] Error:', err)
    return NextResponse.json(
      { error: 'Internal server error' } as ApiResponse,
      { status: 500 }
    )
  }
}
