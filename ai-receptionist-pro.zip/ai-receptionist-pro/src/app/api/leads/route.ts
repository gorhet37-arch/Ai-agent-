// ============================================
// API: Leads
// GET  /api/leads?limit=N   — list leads for authenticated user's business
// POST /api/leads            — create or update a lead
// ============================================
import { NextRequest, NextResponse } from 'next/server'
import { createServerSupabaseClient, createServiceRoleClient } from '@/lib/supabase'
import type { ApiResponse, Lead } from '@/types'

// ── GET: List leads for current user's business ──────────────────────────────
export async function GET(request: NextRequest) {
  try {
    const supabase = await createServerSupabaseClient()
    const { data: { session }, error: sessionErr } = await supabase.auth.getSession()

    if (sessionErr || !session?.user) {
      return NextResponse.json({ error: 'Unauthorized' } as ApiResponse, { status: 401 })
    }

    // Fetch the business profile owned by this user
    const { data: business } = await supabase
      .from('business_profiles')
      .select('id')
      .eq('user_id', session.user.id)
      .maybeSingle()

    if (!business) {
      return NextResponse.json({ success: true, data: [] } as ApiResponse<Lead[]>)
    }

    const { searchParams } = new URL(request.url)
    const limit = Math.min(parseInt(searchParams.get('limit') ?? '100'), 500)

    const { data: leads, error } = await supabase
      .from('leads')
      .select('*')
      .eq('business_id', business.id)
      .order('created_at', { ascending: false })
      .limit(limit)

    if (error) {
      return NextResponse.json({ error: 'Failed to fetch leads' } as ApiResponse, { status: 500 })
    }

    return NextResponse.json({ success: true, data: leads ?? [] } as ApiResponse<Lead[]>)
  } catch (err) {
    console.error('[GET /api/leads]', err)
    return NextResponse.json({ error: 'Internal server error' } as ApiResponse, { status: 500 })
  }
}

// ── POST: Create or update a lead (called by chat API internally) ────────────
export async function POST(request: NextRequest) {
  try {
    // Internal calls use service role; verify by checking a shared secret header
    const authHeader = request.headers.get('Authorization')
    const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY

    // Allow service-role internal calls OR authenticated user calls
    const isServiceCall = authHeader === `Bearer ${serviceKey}`

    const supabase = isServiceCall
      ? createServiceRoleClient()
      : await createServerSupabaseClient()

    if (!isServiceCall) {
      const { data: { session } } = await supabase.auth.getSession()
      if (!session?.user) {
        return NextResponse.json({ error: 'Unauthorized' } as ApiResponse, { status: 401 })
      }
    }

    const body = (await request.json()) as Partial<Lead>

    if (!body.business_id) {
      return NextResponse.json({ error: 'business_id is required' } as ApiResponse, { status: 400 })
    }

    // Upsert: deduplicate by conversation_id if present, else email
    const existing = body.conversation_id
      ? (await supabase.from('leads').select('id').eq('conversation_id', body.conversation_id).maybeSingle()).data
      : body.email
        ? (await supabase.from('leads').select('id').eq('business_id', body.business_id).eq('email', body.email).maybeSingle()).data
        : null

    const leadData = {
      business_id:     body.business_id,
      conversation_id: body.conversation_id || null,
      name:            body.name || 'Unknown',
      email:           body.email || null,
      phone:           body.phone || null,
      service_needed:  body.service_needed || null,
      preferred_date:  body.preferred_date || null,
      score:           body.score || 'cold',
      source:          body.source || 'ai_chat',
      is_converted:    body.is_converted ?? false,
      notes:           body.notes || null,
      updated_at:      new Date().toISOString(),
    }

    const result = existing
      ? await supabase.from('leads').update(leadData).eq('id', existing.id).select().single()
      : await supabase.from('leads').insert({ ...leadData, created_at: new Date().toISOString() }).select().single()

    const { data: lead, error } = result

    if (error || !lead) {
      console.error('[POST /api/leads] DB error:', error)
      return NextResponse.json({ error: 'Failed to save lead' } as ApiResponse, { status: 500 })
    }

    return NextResponse.json({ success: true, data: lead } as ApiResponse<Lead>)
  } catch (err) {
    console.error('[POST /api/leads]', err)
    return NextResponse.json({ error: 'Internal server error' } as ApiResponse, { status: 500 })
  }
}
