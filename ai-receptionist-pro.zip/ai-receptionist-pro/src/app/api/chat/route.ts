// ============================================
// CHAT API ROUTE  POST /api/chat
// ============================================
// This is the core backend endpoint the widget calls on every message.
//
// Request body:
//   { business_id, visitor_id, message, conversation_id? }
//
// Response:
//   { reply, conversation_id, lead_created }
//
// Flow per request:
//   1. Validate & rate-limit by visitor_id (30 msgs / minute)
//   2. Fetch business profile (incl. services, FAQs, hours)
//   3. Check subscription chat limit — reject if exceeded
//   4. Load or create conversation row
//   5. Load last 20 messages for context
//   6. Call AI engine → get reply + extracted lead data
//   7. Persist user message + assistant reply to messages table
//   8. If AI extracted lead info → upsert lead, link to conversation
//   9. Increment subscription chats_used counter
//  10. Return reply to widget
// ============================================
import { NextRequest, NextResponse } from 'next/server'
import { createServiceRoleClient } from '@/lib/supabase'
import { generateReceptionistResponse, calculateLeadScore } from '@/lib/ai-engine'
import { checkRateLimit } from '@/lib/utils'
import type { BusinessProfile, Message } from '@/types'

// ─── Input validation ──────────────────────────────────────────────────────────

interface ChatRequestBody {
  business_id: string
  visitor_id: string
  message: string
  conversation_id?: string
}

function validateBody(body: unknown): { valid: true; data: ChatRequestBody } | { valid: false; error: string } {
  if (!body || typeof body !== 'object') return { valid: false, error: 'Request body is required' }
  const b = body as Record<string, unknown>

  if (!b.business_id || typeof b.business_id !== 'string') return { valid: false, error: 'business_id is required' }
  if (!b.visitor_id  || typeof b.visitor_id  !== 'string') return { valid: false, error: 'visitor_id is required'  }
  if (!b.message     || typeof b.message     !== 'string') return { valid: false, error: 'message is required'     }
  if (b.message.trim().length === 0)                        return { valid: false, error: 'message cannot be empty' }
  if (b.message.length > 2000)                              return { valid: false, error: 'message too long (max 2000 chars)' }

  // UUID format check for business_id
  const uuidRe = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i
  if (!uuidRe.test(b.business_id)) return { valid: false, error: 'business_id must be a valid UUID' }

  return {
    valid: true,
    data: {
      business_id:     b.business_id as string,
      visitor_id:      b.visitor_id  as string,
      message:         b.message.trim() as string,
      conversation_id: typeof b.conversation_id === 'string' ? b.conversation_id : undefined,
    },
  }
}

// ─── Sanitize message text ─────────────────────────────────────────────────────

function sanitizeText(text: string): string {
  // Strip HTML tags and null bytes to prevent stored XSS
  return text
    .replace(/<[^>]*>/g, '')
    .replace(/\0/g, '')
    .trim()
}

// ─── Route handler ─────────────────────────────────────────────────────────────

export async function POST(request: NextRequest) {
  // ── 1. Rate limit by visitor_id (header fallback to IP) ─────────────────────
  const ip = request.headers.get('x-forwarded-for')?.split(',')[0]?.trim() || 'unknown'
  const rateKey = `chat:${ip}`
  const { allowed } = checkRateLimit(rateKey, 30, 60_000) // 30 per minute per IP
  if (!allowed) {
    return NextResponse.json(
      { error: 'Too many messages. Please wait a moment.' },
      { status: 429 }
    )
  }

  // ── 2. Parse & validate body ─────────────────────────────────────────────────
  let rawBody: unknown
  try {
    rawBody = await request.json()
  } catch {
    return NextResponse.json({ error: 'Invalid JSON body' }, { status: 400 })
  }

  const validation = validateBody(rawBody)
  if (!validation.valid) {
    return NextResponse.json({ error: validation.error }, { status: 400 })
  }

  const { business_id, visitor_id, message, conversation_id } = validation.data
  const cleanMessage = sanitizeText(message)

  // ── 3. Fetch business profile ────────────────────────────────────────────────
  const supabase = createServiceRoleClient()

  const { data: business, error: bizError } = await supabase
    .from('business_profiles')
    .select('*')
    .eq('id', business_id)
    .eq('is_active', true)
    .maybeSingle()

  if (bizError || !business) {
    return NextResponse.json({ error: 'Business not found' }, { status: 404 })
  }

  // ── 4. Check subscription chat limit ────────────────────────────────────────
  const { data: subscription } = await supabase
    .from('subscriptions')
    .select('chats_used, chats_limit, status')
    .eq('user_id', business.user_id)
    .maybeSingle()

  if (subscription && subscription.chats_limit > 0) {
    if (subscription.chats_used >= subscription.chats_limit) {
      return NextResponse.json(
        { error: 'This business has reached its monthly chat limit.' },
        { status: 403 }
      )
    }
  }

  // ── 5. Load or create conversation ──────────────────────────────────────────
  let convId = conversation_id

  if (convId) {
    // Verify the conversation belongs to this business & visitor
    const { data: existing } = await supabase
      .from('conversations')
      .select('id, visitor_name, visitor_email, visitor_phone, status')
      .eq('id', convId)
      .eq('business_id', business_id)
      .eq('visitor_id', visitor_id)
      .maybeSingle()

    if (!existing || existing.status === 'closed') {
      convId = undefined // Treat closed/missing as a new conversation
    }
  }

  if (!convId) {
    const { data: newConv, error: convErr } = await supabase
      .from('conversations')
      .insert({
        business_id,
        visitor_id,
        status: 'active',
        source: 'widget',
      })
      .select('id')
      .single()

    if (convErr || !newConv) {
      console.error('[chat] Failed to create conversation:', convErr)
      return NextResponse.json({ error: 'Failed to create conversation' }, { status: 500 })
    }
    convId = newConv.id
  }

  // ── 6. Load last 20 messages for context ────────────────────────────────────
  const { data: messageRows } = await supabase
    .from('messages')
    .select('id, conversation_id, role, content, metadata, created_at')
    .eq('conversation_id', convId)
    .order('created_at', { ascending: true })
    .limit(20)

  const history: Message[] = (messageRows ?? []) as Message[]

  // Gather any known visitor info from previous messages / conversation row
  const { data: convRow } = await supabase
    .from('conversations')
    .select('visitor_name, visitor_email, visitor_phone')
    .eq('id', convId)
    .single()

  const visitorInfo = {
    name:  convRow?.visitor_name  ?? undefined,
    email: convRow?.visitor_email ?? undefined,
    phone: convRow?.visitor_phone ?? undefined,
  }

  // ── 7. Call AI engine ────────────────────────────────────────────────────────
  let aiResult: Awaited<ReturnType<typeof generateReceptionistResponse>>
  try {
    aiResult = await generateReceptionistResponse(
      business as BusinessProfile,
      history,
      cleanMessage,
      visitorInfo
    )
  } catch (aiErr) {
    console.error('[chat] AI engine error:', aiErr)
    return NextResponse.json(
      { error: 'AI service temporarily unavailable. Please try again.' },
      { status: 503 }
    )
  }

  // ── 8. Persist messages (user then assistant) ────────────────────────────────
  const now = new Date().toISOString()

  const { error: insertErr } = await supabase.from('messages').insert([
    {
      conversation_id: convId,
      role: 'user',
      content: cleanMessage,
      created_at: now,
    },
    {
      conversation_id: convId,
      role: 'assistant',
      content: aiResult.response,
    },
  ])

  if (insertErr) {
    console.error('[chat] Failed to insert messages:', insertErr)
    // Non-fatal for the user — still return the reply
  }

  // Touch conversation updated_at
  await supabase
    .from('conversations')
    .update({ updated_at: new Date().toISOString() })
    .eq('id', convId)

  // ── 9. Create / update lead if AI extracted contact info ─────────────────────
  let leadCreated = false
  const { extractedData } = aiResult

  if (extractedData.shouldCreateLead && extractedData.name) {
    const messageCount = history.length + 2

    const score = calculateLeadScore({
      hasEmail:          !!extractedData.email,
      hasPhone:          !!extractedData.phone,
      hasServiceInterest: !!extractedData.service,
      hasPreferredDate:  !!extractedData.preferredDate,
      messageCount,
    })

    // Check for existing lead on this conversation first
    const { data: existingLead } = await supabase
      .from('leads')
      .select('id, email, phone')
      .eq('conversation_id', convId)
      .maybeSingle()

    if (existingLead) {
      // Update the existing lead with any new info
      await supabase
        .from('leads')
        .update({
          name:         extractedData.name,
          email:        extractedData.email || existingLead.email,
          phone:        extractedData.phone || existingLead.phone,
          service_needed: extractedData.service,
          preferred_date: extractedData.preferredDate,
          score,
          updated_at: new Date().toISOString(),
        })
        .eq('id', existingLead.id)
    } else {
      // Insert new lead
      const { data: newLead, error: leadErr } = await supabase
        .from('leads')
        .insert({
          business_id,
          conversation_id: convId,
          name:             extractedData.name,
          email:            extractedData.email  ?? null,
          phone:            extractedData.phone  ?? null,
          service_needed:   extractedData.service ?? null,
          preferred_date:   extractedData.preferredDate ?? null,
          score,
          source: 'ai_chat',
          is_converted: false,
        })
        .select('id')
        .single()

      if (!leadErr && newLead) {
        leadCreated = true

        // Link lead to conversation
        await supabase
          .from('conversations')
          .update({
            lead_id:       newLead.id,
            visitor_name:  extractedData.name  ?? null,
            visitor_email: extractedData.email ?? null,
            visitor_phone: extractedData.phone ?? null,
          })
          .eq('id', convId)
      } else if (leadErr) {
        console.error('[chat] Failed to insert lead:', leadErr)
      }
    }
  }

  // Update visitor info on conversation if newly collected
  if (extractedData.name || extractedData.email || extractedData.phone) {
    const updates: Record<string, string> = {}
    if (extractedData.name  && !visitorInfo.name)  updates.visitor_name  = extractedData.name
    if (extractedData.email && !visitorInfo.email) updates.visitor_email = extractedData.email
    if (extractedData.phone && !visitorInfo.phone) updates.visitor_phone = extractedData.phone

    if (Object.keys(updates).length > 0) {
      await supabase.from('conversations').update(updates).eq('id', convId)
    }
  }

  // ── 10. Increment chats_used ─────────────────────────────────────────────────
  if (subscription) {
    await supabase
      .from('subscriptions')
      .update({ chats_used: subscription.chats_used + 1 })
      .eq('user_id', business.user_id)
  }

  // ── 11. Return response ──────────────────────────────────────────────────────
  return NextResponse.json({
    reply: aiResult.response,
    conversation_id: convId,
    lead_created: leadCreated,
  })
}

// OPTIONS — allow cross-origin requests from widget embeds
export async function OPTIONS(request: NextRequest) {
  const origin = request.headers.get('origin')
  
  // FIX 6: Restrict CORS to approved domains
  const approvedOrigins = [
    'http://localhost:3000',
    'http://localhost:3001',
    process.env.NEXT_PUBLIC_APP_URL || '',
  ].filter(Boolean)
  
  const allowOrigin = approvedOrigins.includes(origin || '') 
    ? origin 
    : approvedOrigins[0]

  const headers: Record<string, string> = {
    'Access-Control-Allow-Origin':  allowOrigin || 'http://localhost:3000',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Max-Age':       '86400',
  }

  return new NextResponse(null, {
    status: 204,
    headers,
  })
}
