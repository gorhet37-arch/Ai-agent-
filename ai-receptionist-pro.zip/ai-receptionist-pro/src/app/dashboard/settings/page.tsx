'use client'
import { useEffect, useState } from 'react'
import BusinessProfileForm from '@/components/forms/BusinessProfileForm'
import { Loader2, Settings, Bot, Palette, Clock, List, HelpCircle } from 'lucide-react'
import type { BusinessProfile } from '@/types'

export default function SettingsPage() {
  const [profile, setProfile] = useState<BusinessProfile | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    async function fetchProfile() {
      try {
        const res = await fetch('/api/business/profile')
        if (res.ok) {
          const data = (await res.json()) as { data: BusinessProfile }
          setProfile(data.data)
        } else if (res.status !== 404) {
          setError('Failed to load profile. Please refresh.')
        }
        // 404 = no profile yet, form shows blank — that's correct
      } catch {
        setError('Network error. Please refresh.')
      } finally {
        setLoading(false)
      }
    }
    fetchProfile()
  }, [])

  return (
    <div className="space-y-6 animate-fade-in max-w-5xl">
      {/* Header */}
      <div className="flex items-start justify-between gap-4 flex-wrap">
        <div>
          <h1 className="page-title">Business Settings</h1>
          <p className="page-subtitle">
            {profile
              ? `Editing profile for ${profile.business_name}`
              : 'Set up your AI receptionist for the first time'}
          </p>
        </div>
        {!profile && (
          <div className="flex items-center gap-2 text-xs text-brand-700 bg-brand-50 border border-brand-100 rounded-lg px-3 py-2">
            <Bot className="w-3.5 h-3.5" />
            Complete setup to activate your widget
          </div>
        )}
      </div>

      {/* Setup guide for new users */}
      {!loading && !profile && (
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {[
            { icon: Settings,    label: 'Basic Info',     desc: 'Name, industry, contact' },
            { icon: Clock,       label: 'Business Hours', desc: 'When you are open' },
            { icon: List,        label: 'Services',       desc: 'What you offer' },
            { icon: Palette,     label: 'Widget Style',   desc: 'Colours and branding' },
          ].map((step, i) => (
            <div key={step.label} className="bg-brand-50 border border-brand-100 rounded-xl p-4 flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-brand-600 text-white flex items-center justify-center text-xs font-bold shrink-0">
                {i + 1}
              </div>
              <div>
                <p className="text-sm font-semibold text-brand-800">{step.label}</p>
                <p className="text-xs text-brand-600">{step.desc}</p>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Form area */}
      {loading ? (
        <div className="card flex items-center justify-center py-20">
          <Loader2 className="w-6 h-6 animate-spin text-brand-600" />
        </div>
      ) : error ? (
        <div className="card p-6 flex items-center gap-3 text-danger-600 bg-danger-50 border-danger-200">
          <HelpCircle className="w-5 h-5 shrink-0" />
          <p className="text-sm">{error}</p>
        </div>
      ) : (
        <div className="card p-0 overflow-hidden">
          <BusinessProfileForm profile={profile} />
        </div>
      )}
    </div>
  )
}
