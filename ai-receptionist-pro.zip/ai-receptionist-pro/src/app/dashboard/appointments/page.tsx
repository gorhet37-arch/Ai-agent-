import Link from 'next/link'
import { Calendar, ArrowRight, Clock } from 'lucide-react'

export default function AppointmentsPage() {
  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="page-title">Appointments</h1>
        <p className="page-subtitle">Bookings made through your AI receptionist</p>
      </div>
      <div className="card empty-state gap-4">
        <div className="w-16 h-16 rounded-2xl bg-success-50 flex items-center justify-center">
          <Calendar className="w-8 h-8 text-success-500" />
        </div>
        <div>
          <h3 className="font-semibold text-surface-700 text-lg">Appointments coming soon</h3>
          <p className="text-surface-400 text-sm mt-1 max-w-sm">
            Connect Google Calendar in settings to start receiving AI-booked appointments.
          </p>
        </div>
        <div className="flex gap-3">
          <Link href="/dashboard/settings" className="btn btn-primary btn-sm gap-2">
            Connect Calendar <ArrowRight className="w-3.5 h-3.5" />
          </Link>
          <div className="flex items-center gap-2 text-xs text-surface-400 bg-surface-50 rounded-lg px-4 py-2.5 border border-surface-200">
            <Clock className="w-3.5 h-3.5" />
            v1.1
          </div>
        </div>
      </div>
    </div>
  )
}
