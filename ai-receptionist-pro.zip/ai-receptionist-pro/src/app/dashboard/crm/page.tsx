import { BarChart3, Clock } from 'lucide-react'

export default function AnalyticsPage() {
  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="page-title">Analytics</h1>
        <p className="page-subtitle">Conversion rates, trends, and business insights</p>
      </div>
      <div className="card empty-state gap-4">
        <div className="w-16 h-16 rounded-2xl bg-warning-50 flex items-center justify-center">
          <BarChart3 className="w-8 h-8 text-warning-500" />
        </div>
        <div>
          <h3 className="font-semibold text-surface-700 text-lg">Analytics coming soon</h3>
          <p className="text-surface-400 text-sm mt-1 max-w-sm">
            Detailed charts and insights on lead conversion, chat volume, and more.
          </p>
        </div>
        <div className="flex items-center gap-2 text-xs text-surface-400 bg-surface-50 rounded-lg px-4 py-2.5 border border-surface-200">
          <Clock className="w-3.5 h-3.5" />
          Available in v1.1
        </div>
      </div>
    </div>
  )
}
