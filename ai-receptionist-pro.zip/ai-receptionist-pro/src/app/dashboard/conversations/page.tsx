import { MessageSquare, Clock, Search } from 'lucide-react'

export default function ConversationsPage() {
  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="page-title">Conversations</h1>
        <p className="page-subtitle">Full chat history with all visitors</p>
      </div>
      <div className="card empty-state gap-4">
        <div className="w-16 h-16 rounded-2xl bg-accent-50 flex items-center justify-center">
          <MessageSquare className="w-8 h-8 text-accent-500" />
        </div>
        <div>
          <h3 className="font-semibold text-surface-700 text-lg">Conversations coming soon</h3>
          <p className="text-surface-400 text-sm mt-1 max-w-sm">
            Full conversation history and search will be available in the next update.
          </p>
        </div>
        <div className="flex items-center gap-2 text-xs text-surface-400 bg-surface-50 rounded-lg px-4 py-2.5 border border-surface-200">
          <Clock className="w-3.5 h-3.5" />
          Available in v1.1
        </div>
      </div>
    </div>
  )
}
