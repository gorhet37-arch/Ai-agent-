import { Bell } from 'lucide-react'

export default function NotificationsPage() {
  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="page-title">Notifications</h1>
        <p className="page-subtitle">Alerts for new leads and appointments</p>
      </div>
      <div className="card empty-state gap-4">
        <div className="w-16 h-16 rounded-2xl bg-brand-50 flex items-center justify-center">
          <Bell className="w-8 h-8 text-brand-500" />
        </div>
        <div>
          <h3 className="font-semibold text-surface-700 text-lg">All caught up!</h3>
          <p className="text-surface-400 text-sm mt-1 max-w-sm">
            You&apos;ll receive notifications here when new leads arrive or appointments are booked.
          </p>
        </div>
      </div>
    </div>
  )
}
