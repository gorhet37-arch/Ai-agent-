'use client'
import { useEffect, useState } from 'react'
import {
  Search, TrendingUp, Users, Flame, Thermometer,
  Snowflake, Mail, Phone, Calendar, ChevronDown,
  ChevronUp, Loader2, RefreshCw
} from 'lucide-react'
import { cn, timeAgo, getLeadScoreColor, getLeadScoreEmoji } from '@/lib/utils'
import type { Lead } from '@/types'

type ScoreFilter = 'all' | 'hot' | 'warm' | 'cold'

export default function LeadsDashboard() {
  const [leads, setLeads] = useState<Lead[]>([])
  const [loading, setLoading] = useState(true)
  const [refreshing, setRefreshing] = useState(false)
  const [searchQuery, setSearchQuery] = useState('')
  const [scoreFilter, setScoreFilter] = useState<ScoreFilter>('all')
  const [expandedId, setExpandedId] = useState<string | null>(null)

  const fetchLeads = async (showRefresh = false) => {
    if (showRefresh) setRefreshing(true)
    try {
      // Auth is on the server — no need to pass business_id, the API resolves it from session
      const res = await fetch('/api/leads?limit=500')
      if (res.ok) {
        const data = (await res.json()) as { data: Lead[] }
        setLeads(data.data ?? [])
      }
    } catch (err) {
      console.error('Failed to fetch leads:', err)
    } finally {
      setLoading(false)
      setRefreshing(false)
    }
  }

  useEffect(() => { fetchLeads() }, [])

  const filtered = leads.filter(l => {
    const matchesScore = scoreFilter === 'all' || l.score === scoreFilter
    const q = searchQuery.toLowerCase()
    const matchesQuery = !q ||
      l.name?.toLowerCase().includes(q) ||
      l.email?.toLowerCase().includes(q) ||
      l.phone?.toLowerCase().includes(q) ||
      l.service_needed?.toLowerCase().includes(q)
    return matchesScore && matchesQuery
  })

  const counts = {
    all:  leads.length,
    hot:  leads.filter(l => l.score === 'hot').length,
    warm: leads.filter(l => l.score === 'warm').length,
    cold: leads.filter(l => l.score === 'cold').length,
  }

  const filters: { key: ScoreFilter; label: string; icon: React.ElementType; count: number; color: string }[] = [
    { key: 'all',  label: 'All Leads', icon: Users,       count: counts.all,  color: 'text-surface-600' },
    { key: 'hot',  label: 'Hot',       icon: Flame,       count: counts.hot,  color: 'text-red-600' },
    { key: 'warm', label: 'Warm',      icon: Thermometer, count: counts.warm, color: 'text-orange-600' },
    { key: 'cold', label: 'Cold',      icon: Snowflake,   count: counts.cold, color: 'text-blue-600' },
  ]

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div>
          <h1 className="page-title">Leads</h1>
          <p className="page-subtitle">{counts.all} total leads captured by your AI</p>
        </div>
        <button onClick={() => fetchLeads(true)}
          className="btn btn-secondary btn-sm gap-2" disabled={refreshing}>
          <RefreshCw className={cn('w-3.5 h-3.5', refreshing && 'animate-spin')} />
          Refresh
        </button>
      </div>

      {/* Score summary cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        {[
          { label: 'All Leads',  value: counts.all,  emoji: '📋', color: 'border-surface-200 bg-white' },
          { label: 'Hot',        value: counts.hot,  emoji: '🔥', color: 'border-red-200 bg-red-50' },
          { label: 'Warm',       value: counts.warm, emoji: '🌤', color: 'border-orange-200 bg-orange-50' },
          { label: 'Cold',       value: counts.cold, emoji: '❄️', color: 'border-blue-200 bg-blue-50' },
        ].map(s => (
          <div key={s.label} className={`rounded-xl border p-4 ${s.color}`}>
            <div className="text-2xl mb-1">{s.emoji}</div>
            <div className="text-xl font-bold text-surface-900">{s.value}</div>
            <div className="text-xs text-surface-500">{s.label}</div>
          </div>
        ))}
      </div>

      {/* Filters + Search */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1 max-w-xs">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-surface-400" />
          <input
            type="text"
            placeholder="Search leads..."
            className="input pl-10 h-10 text-sm"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
          />
        </div>
        <div className="flex gap-2 flex-wrap">
          {filters.map(f => (
            <button
              key={f.key}
              onClick={() => setScoreFilter(f.key)}
              className={cn(
                'flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium border transition-all',
                scoreFilter === f.key
                  ? 'bg-brand-600 text-white border-brand-600'
                  : 'bg-white text-surface-600 border-surface-200 hover:border-surface-300'
              )}
            >
              <f.icon className="w-3.5 h-3.5" />
              {f.label}
              <span className={cn(
                'ml-1 text-xs px-1.5 py-0.5 rounded-full font-semibold',
                scoreFilter === f.key ? 'bg-white/20 text-white' : 'bg-surface-100 text-surface-500'
              )}>
                {f.count}
              </span>
            </button>
          ))}
        </div>
      </div>

      {/* Table */}
      {loading ? (
        <div className="flex items-center justify-center py-20">
          <Loader2 className="w-6 h-6 animate-spin text-brand-600" />
        </div>
      ) : filtered.length === 0 ? (
        <div className="card empty-state">
          <TrendingUp className="w-12 h-12 text-surface-200 mb-4" />
          <h3 className="font-semibold text-surface-600 mb-1">
            {leads.length === 0 ? 'No leads yet' : 'No leads match your filter'}
          </h3>
          <p className="text-sm text-surface-400 max-w-sm">
            {leads.length === 0
              ? 'Leads will appear here once visitors chat with your AI widget'
              : 'Try adjusting your search or filter'}
          </p>
        </div>
      ) : (
        <div className="card overflow-hidden">
          <div className="table-wrapper">
            <table className="table">
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Score</th>
                  <th className="hidden sm:table-cell">Contact</th>
                  <th className="hidden md:table-cell">Service Needed</th>
                  <th className="hidden lg:table-cell">Captured</th>
                  <th className="w-10"></th>
                </tr>
              </thead>
              <tbody>
                {filtered.map(lead => (
                  <>
                    <tr key={lead.id}
                      className="cursor-pointer"
                      onClick={() => setExpandedId(expandedId === lead.id ? null : lead.id)}>
                      <td>
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-full bg-brand-100 text-brand-700 font-bold text-xs flex items-center justify-center shrink-0">
                            {(lead.name?.[0] ?? '?').toUpperCase()}
                          </div>
                          <div>
                            <p className="font-medium text-surface-800 text-sm">{lead.name ?? 'Unknown'}</p>
                            <p className="text-xs text-surface-400 sm:hidden">{lead.email ?? lead.phone ?? ''}</p>
                          </div>
                        </div>
                      </td>
                      <td>
                        <span className={`badge ${getLeadScoreColor(lead.score)}`}>
                          {getLeadScoreEmoji(lead.score)} {lead.score}
                        </span>
                      </td>
                      <td className="hidden sm:table-cell">
                        <div className="space-y-0.5">
                          {lead.email && (
                            <div className="flex items-center gap-1.5 text-xs text-surface-500">
                              <Mail className="w-3 h-3" /> {lead.email}
                            </div>
                          )}
                          {lead.phone && (
                            <div className="flex items-center gap-1.5 text-xs text-surface-500">
                              <Phone className="w-3 h-3" /> {lead.phone}
                            </div>
                          )}
                          {!lead.email && !lead.phone && <span className="text-xs text-surface-300">No contact info</span>}
                        </div>
                      </td>
                      <td className="hidden md:table-cell">
                        <span className="text-sm text-surface-600">{lead.service_needed ?? '—'}</span>
                      </td>
                      <td className="hidden lg:table-cell">
                        <span className="text-xs text-surface-400">{timeAgo(lead.created_at)}</span>
                      </td>
                      <td>
                        {expandedId === lead.id
                          ? <ChevronUp className="w-4 h-4 text-surface-400" />
                          : <ChevronDown className="w-4 h-4 text-surface-400" />
                        }
                      </td>
                    </tr>
                    {expandedId === lead.id && (
                      <tr key={`${lead.id}-expanded`} className="bg-surface-50">
                        <td colSpan={6} className="px-5 py-4">
                          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 text-sm">
                            <div>
                              <p className="text-xs font-semibold text-surface-400 uppercase tracking-wider mb-1">Contact</p>
                              <p className="text-surface-700">{lead.email ?? '—'}</p>
                              <p className="text-surface-700">{lead.phone ?? '—'}</p>
                            </div>
                            <div>
                              <p className="text-xs font-semibold text-surface-400 uppercase tracking-wider mb-1">Service</p>
                              <p className="text-surface-700">{lead.service_needed ?? '—'}</p>
                            </div>
                            <div>
                              <p className="text-xs font-semibold text-surface-400 uppercase tracking-wider mb-1">Preferred Date</p>
                              <div className="flex items-center gap-1.5 text-surface-700">
                                <Calendar className="w-3.5 h-3.5" />
                                {lead.preferred_date ?? '—'}
                              </div>
                            </div>
                            <div>
                              <p className="text-xs font-semibold text-surface-400 uppercase tracking-wider mb-1">Notes</p>
                              <p className="text-surface-700">{lead.notes ?? '—'}</p>
                            </div>
                          </div>
                        </td>
                      </tr>
                    )}
                  </>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  )
}
