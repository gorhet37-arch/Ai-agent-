import { redirect } from 'next/navigation'
import { createServerSupabaseClient } from '@/lib/supabase'
import DashboardSidebar from '@/components/dashboard/Sidebar'
import DashboardTopbar from '@/components/dashboard/Topbar'
import { Toaster } from 'react-hot-toast'

export default async function DashboardLayout({ children }: { children: React.ReactNode }) {
  const supabase = await createServerSupabaseClient()
  const { data: { session } } = await supabase.auth.getSession()
  if (!session) redirect('/auth/login')

  const userId = session.user.id

  const [
    { data: userData },
    { data: business },
    { data: subscription },
  ] = await Promise.all([
    supabase.from('users').select('full_name, email').eq('id', userId).maybeSingle(),
    supabase.from('business_profiles').select('id, business_name').eq('user_id', userId).maybeSingle(),
    supabase.from('subscriptions').select('plan, chats_used, chats_limit, status').eq('user_id', userId).maybeSingle(),
  ])

  const user = {
    full_name: userData?.full_name ?? session.user.user_metadata?.full_name ?? null,
    email: userData?.email ?? session.user.email ?? '',
  }

  return (
    <div className="flex h-screen overflow-hidden bg-surface-50">
      <Toaster position="top-right" toastOptions={{ className: 'text-sm font-medium' }} />

      <DashboardSidebar
        user={user}
        business={business ?? null}
        subscription={subscription ? {
          plan: subscription.plan,
          chats_used: subscription.chats_used ?? 0,
          chats_limit: subscription.chats_limit ?? 500,
        } : null}
        userRole="owner"
      />

      <div className="flex-1 flex flex-col overflow-hidden">
        <DashboardTopbar
          user={user}
          business={business ?? null}
          unreadNotifications={0}
        />
        <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8">
          {children}
        </main>
      </div>
    </div>
  )
}
