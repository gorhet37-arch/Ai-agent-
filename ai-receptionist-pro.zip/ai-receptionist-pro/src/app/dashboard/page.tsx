import { redirect } from 'next/navigation'
import { createServerSupabaseClient } from '@/lib/supabase'
import Link from 'next/link'
import {
  Users, MessageSquare, TrendingUp, Calendar,
  ArrowRight, Bot, Zap, Settings, ExternalLink,
  CheckCircle2, AlertCircle
} from 'lucide-react'

export default async function DashboardPage() {
  const supabase = await createServerSupabaseClient()
  const { data: { session } } = await supabase.auth.getSession()
  if (!session) redirect('/auth/login')

  const userId = session.user.id

  // Fetch business first (needed for leads/conversations queries)
  const { data: business } = await supabase
    .from('business_profiles')
    .select('id, business_name')
    .eq('user_id', userId)
    .maybeSingle()

  const businessId = business?.id ?? ''

  // Now fetch everything that depends on businessId
  const [
    { data: subscription },
    { count: leadsCount },
    { count: convsCount },
    { data: recentLeads },
  ] = await Promise.all([
    supabase.from('subscriptions').select('plan, chats_used, chats_limit, status').eq('user_id', userId).maybeSingle(),
    supabase.from('leads').select('*', { count: 'exact', head: true }).eq('business_id', businessId),
    supabase.from('conversations').select('*', { count: 'exact', head: true }).eq('business_id', businessId),
    supabase.from('leads').select('id, name, email, score, service_needed, created_at').eq('business_id', businessId).order('created_at', { ascending: false }).limit(5),
  ])

  const isNewUser = !business
  const chatPercent = subscription
    ? Math.round((subscription.chats_used / (subscription.chats_limit || 500)) * 100)
    : 0

  const hotLeads = recentLeads?.filter(l => l.score === 'hot').length ?? 0
  const conversionRate = leadsCount ? `${Math.round((hotLeads / leadsCount) * 100)}%` : '—'

  const stats = [
    { label: 'Total Leads',     value: (leadsCount ?? 0).toString(),                   icon: Users,          color: 'text-brand-600',   bg: 'bg-brand-50',   change: 'All time' },
    { label: 'Conversations',   value: (convsCount ?? 0).toString(),                   icon: MessageSquare,  color: 'text-accent-600',  bg: 'bg-accent-50',  change: 'All time' },
    { label: 'AI Chats Used',   value: `${subscription?.chats_used ?? 0}`,             icon: Zap,            color: 'text-warning-600', bg: 'bg-warning-50', change: `of ${subscription?.chats_limit ?? 500} this month` },
    { label: 'Hot Lead Rate',   value: conversionRate,                                 icon: TrendingUp,     color: 'text-success-600', bg: 'bg-success-50', change: 'Hot leads ratio' },
  ]

  const scoreColors: Record<string, string> = { hot: 'badge-hot', warm: 'badge-warm', cold: 'badge-cold' }
  const scoreEmoji:  Record<string, string> = { hot: '🔥', warm: '🌤', cold: '❄️' }

  return (
    <div className="space-y-8 animate-fade-in">
      {/* Header */}
      <div className="flex items-start justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-2xl font-bold text-surface-900">
            {isNewUser ? 'Welcome 👋' : `Dashboard`}
          </h1>
          <p className="text-surface-500 text-sm mt-1">
            {isNewUser
              ? "Let's get your AI receptionist set up."
              : `${business?.business_name ?? 'Your business'} — overview`}
          </p>
        </div>
        {business && (
          <Link href={`/widget/${business.id}`} target="_blank" className="btn btn-outline btn-sm gap-2">
            <div className="w-2 h-2 rounded-full bg-success-500 animate-pulse" />
            View Widget
            <ExternalLink className="w-3.5 h-3.5" />
          </Link>
        )}
      </div>

      {/* Setup banner for new users */}
      {isNewUser && (
        <div className="card p-6 bg-gradient-to-r from-brand-600 to-brand-700 border-0 text-white">
          <div className="flex items-start justify-between gap-4 flex-wrap">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-xl bg-white/20 flex items-center justify-center shrink-0">
                <Bot className="w-6 h-6 text-white" />
              </div>
              <div>
                <h3 className="font-bold text-lg mb-1">Set up your AI receptionist</h3>
                <p className="text-white/75 text-sm leading-relaxed">
                  Add your business info so your AI can answer questions and capture leads.
                </p>
              </div>
            </div>
            <Link href="/dashboard/settings" className="btn bg-white text-brand-700 hover:bg-brand-50 btn-md shrink-0 gap-2">
              <Settings className="w-4 h-4" />
              Configure Now
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
          <div className="mt-6 grid sm:grid-cols-3 gap-3">
            {[
              { step: 1, label: 'Add business info' },
              { step: 2, label: 'Get embed code' },
              { step: 3, label: 'Add to your website' },
            ].map(item => (
              <div key={item.step} className="flex items-center gap-3 bg-white/10 rounded-xl p-3">
                <div className="w-5 h-5 rounded-full border-2 border-white/40 flex items-center justify-center shrink-0 text-xs font-bold">{item.step}</div>
                <span className="text-sm text-white/90">{item.label}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Stats */}
      <div className="grid sm:grid-cols-2 xl:grid-cols-4 gap-5">
        {stats.map(stat => (
          <div key={stat.label} className="card p-5">
            <div className="flex items-center justify-between mb-4">
              <span className="text-sm font-medium text-surface-500">{stat.label}</span>
              <div className={`w-9 h-9 rounded-xl ${stat.bg} flex items-center justify-center`}>
                <stat.icon className={`w-[18px] h-[18px] ${stat.color}`} />
              </div>
            </div>
            <div className="text-3xl font-bold text-surface-900 mb-1">{stat.value}</div>
            <div className="text-xs text-surface-400">{stat.change}</div>
          </div>
        ))}
      </div>

      <div className="grid lg:grid-cols-5 gap-6">
        {/* Recent Leads */}
        <div className="lg:col-span-3 card">
          <div className="p-5 border-b border-surface-100 flex items-center justify-between">
            <h2 className="font-semibold text-surface-900">Recent Leads</h2>
            <Link href="/dashboard/leads" className="text-xs text-brand-600 hover:text-brand-700 font-medium flex items-center gap-1">
              View all <ArrowRight className="w-3 h-3" />
            </Link>
          </div>
          {!recentLeads || recentLeads.length === 0 ? (
            <div className="p-8 text-center">
              <Users className="w-10 h-10 text-surface-200 mx-auto mb-3" />
              <p className="font-medium text-surface-400 text-sm">No leads yet</p>
              <p className="text-xs text-surface-300 mt-1">
                {isNewUser ? 'Set up your widget to start capturing leads' : 'Leads appear here after visitors chat with your AI'}
              </p>
              {isNewUser && (
                <Link href="/dashboard/settings" className="btn btn-primary btn-sm mt-4 gap-1">
                  <Settings className="w-3.5 h-3.5" /> Set Up Widget
                </Link>
              )}
            </div>
          ) : (
            <div className="divide-y divide-surface-50">
              {recentLeads.map(lead => (
                <div key={lead.id} className="flex items-center gap-4 p-4 hover:bg-surface-50 transition-colors">
                  <div className="w-9 h-9 rounded-full bg-brand-100 flex items-center justify-center text-brand-700 font-bold text-sm shrink-0">
                    {(lead.name?.[0] ?? '?').toUpperCase()}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-surface-800 text-sm truncate">{lead.name ?? 'Unknown'}</p>
                    <p className="text-xs text-surface-400 truncate">{lead.email ?? lead.service_needed ?? 'No contact info'}</p>
                  </div>
                  <span className={`badge ${scoreColors[lead.score] ?? 'badge-gray'} shrink-0`}>
                    {scoreEmoji[lead.score]} {lead.score}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Right panel */}
        <div className="lg:col-span-2 space-y-5">
          {/* Chat usage */}
          <div className="card p-5">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold text-surface-900 text-sm">Chat Usage</h3>
              <span className="badge badge-blue capitalize">{subscription?.plan ?? 'starter'}</span>
            </div>
            <div className="flex items-end justify-between mb-2">
              <span className="text-2xl font-bold text-surface-900">{subscription?.chats_used ?? 0}</span>
              <span className="text-sm text-surface-400">/ {subscription?.chats_limit ?? 500}</span>
            </div>
            <div className="h-2 bg-surface-100 rounded-full overflow-hidden mb-2">
              <div
                className={`h-full rounded-full transition-all ${chatPercent > 80 ? 'bg-danger-500' : chatPercent > 60 ? 'bg-warning-500' : 'bg-brand-500'}`}
                style={{ width: `${Math.min(chatPercent, 100)}%` }}
              />
            </div>
            <p className="text-xs text-surface-400">{chatPercent}% used this month</p>
            {chatPercent > 80 && (
              <div className="mt-3 flex items-center gap-2 text-xs text-warning-700 bg-warning-50 rounded-lg p-2.5 border border-warning-200">
                <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                Approaching limit — consider upgrading
              </div>
            )}
          </div>

          {/* Quick actions */}
          <div className="card p-5">
            <h3 className="font-semibold text-surface-900 text-sm mb-4">Quick Actions</h3>
            <div className="space-y-1">
              {[
                { label: 'Business Settings', icon: Settings,      href: '/dashboard/settings',     desc: 'Profile & AI config' },
                { label: 'View Leads',         icon: Users,         href: '/dashboard/leads',         desc: 'Captured contacts' },
                { label: 'Conversations',      icon: MessageSquare, href: '/dashboard/conversations', desc: 'Chat history' },
                { label: 'Appointments',       icon: Calendar,      href: '/dashboard/appointments',  desc: 'Bookings' },
              ].map(action => (
                <Link key={action.href} href={action.href}
                  className="flex items-center gap-3 p-2.5 rounded-xl hover:bg-surface-50 transition-colors group">
                  <div className="w-8 h-8 rounded-lg bg-surface-100 group-hover:bg-brand-100 flex items-center justify-center transition-colors shrink-0">
                    <action.icon className="w-4 h-4 text-surface-500 group-hover:text-brand-600 transition-colors" />
                  </div>
                  <div className="min-w-0">
                    <p className="text-sm font-medium text-surface-800 truncate">{action.label}</p>
                    <p className="text-xs text-surface-400 truncate">{action.desc}</p>
                  </div>
                  <ArrowRight className="w-3.5 h-3.5 text-surface-300 group-hover:text-brand-500 ml-auto shrink-0 transition-colors" />
                </Link>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
