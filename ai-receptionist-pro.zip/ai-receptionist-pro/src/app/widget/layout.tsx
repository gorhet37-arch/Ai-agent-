// ============================================
// WIDGET LAYOUT
// ============================================
// Public route — no auth required, no dashboard sidebar.
// Renders the widget in two modes:
//   1. Preview: /widget/[id] — shows chat widget in an iframe-safe preview
//   2. Embed: /widget/[id]?embed=1 — returns just the widget for external sites

import './widget.css'

export default function WidgetLayout({ children }: { children: React.ReactNode }) {
  return <>{children}</>
}
