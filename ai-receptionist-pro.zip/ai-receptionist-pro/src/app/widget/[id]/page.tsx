'use client'
// ============================================
// WIDGET PAGE — /widget/[id]
// ============================================
// Two rendering modes:
//
// 1. Preview mode (default):
//    - User views /widget/[business_id]
//    - Shows the chat widget in an iframe-ready container
//    - Side panel shows embed code to copy
//    - User can test the widget in real-time
//
// 2. Embed mode (for website integration):
//    - External website loads a <script> tag
//    - Script fetches /widget/[id]?embed=1
//    - Returns minimal HTML that injects ChatWidget
//    - (Implemented via client-side route guards in this component)
//
// When the business profile is not found, returns a 404 page.
// ============================================
import { useEffect, useState } from 'react'
import { useParams, useSearchParams } from 'next/navigation'
import ChatWidget from '@/components/chat/ChatWidget'
import type { ChatConfig } from '@/components/chat/ChatWidget'
import { Copy, Check, Code, AlertCircle } from 'lucide-react'

export default function WidgetPage() {
  const params = useParams()
  const searchParams = useSearchParams()
  const businessId = params.id as string
  const isEmbed = searchParams.get('embed') === '1'

  const [config, setConfig] = useState<ChatConfig | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [copied, setCopied] = useState(false)

  // Fetch business profile to get widget config
  useEffect(() => {
    async function fetchConfig() {
      try {
        const res = await fetch(`/api/widget/config?business_id=${businessId}`, {
          method: 'GET',
        })

        if (!res.ok) {
          if (res.status === 404) {
            setError('Business not found')
          } else {
            setError('Failed to load widget configuration')
          }
          setLoading(false)
          return
        }

        const data = (await res.json()) as ChatConfig
        setConfig(data)
        setLoading(false)
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Something went wrong')
        setLoading(false)
      }
    }

    if (businessId) {
      fetchConfig()
    }
  }, [businessId])

  // Loading state
  if (loading) {
    return (
      <div className="w-screen h-screen bg-gradient-to-br from-slate-900 to-slate-800
                      flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 rounded-full border-4 border-slate-700 border-t-blue-500
                          animate-spin mx-auto mb-4" />
          <p className="text-slate-300">Loading widget...</p>
        </div>
      </div>
    )
  }

  // Error state
  if (error || !config) {
    return (
      <div className="w-screen h-screen bg-gradient-to-br from-slate-900 to-slate-800
                      flex items-center justify-center px-4">
        <div className="max-w-md text-center">
          <AlertCircle className="w-12 h-12 text-red-400 mx-auto mb-4" />
          <h1 className="text-xl font-bold text-white mb-2">Widget Not Found</h1>
          <p className="text-slate-400 mb-6">
            {error || 'Unable to load this widget. Check the business ID and try again.'}
          </p>
          <a
            href="/"
            className="inline-block px-6 py-2 rounded-lg bg-blue-600 text-white font-medium
                       hover:bg-blue-700 transition-colors"
          >
            Back to Home
          </a>
        </div>
      </div>
    )
  }

  // Embed mode — minimal HTML (used by embed.js script on external sites)
  if (isEmbed) {
    return (
      <html>
        <head>
          <meta charSet="utf-8" />
          <meta name="viewport" content="width=device-width, initial-scale=1" />
          <title>AI Receptionist Chat</title>
          <style>{`
            * { margin: 0; padding: 0; box-sizing: border-box; }
            html, body { width: 100%; height: 100%; overflow: hidden; }
            body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; }
          `}</style>
        </head>
        <body>
          <div id="widget-container" />
          <script>{`
            // Widget will be hydrated by React
            window.__widgetConfig = ${JSON.stringify(config)};
          `}</script>
        </body>
      </html>
    )
  }

  // Preview mode — shows widget + embed code
  const embedCode = `<script src="${process.env.NEXT_PUBLIC_APP_URL || 'https://example.com'}/widget/embed.js" data-business-id="${businessId}"></script>`

  const handleCopyCode = async () => {
    try {
      await navigator.clipboard.writeText(embedCode)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    } catch {
      alert('Failed to copy code')
    }
  }

  return (
    <div className="w-screen h-screen bg-gradient-to-br from-slate-50 to-slate-100 flex">
      {/* Left: Widget Preview */}
      <div className="flex-1 flex flex-col items-center justify-center p-6">
        <div className="w-full max-w-md mb-6">
          <h1 className="text-2xl font-bold text-slate-900 mb-1">Widget Preview</h1>
          <p className="text-slate-500 text-sm">
            This is how your chat widget will appear on your website
          </p>
        </div>

        {/* Widget Container */}
        <div className="w-full max-w-md bg-white rounded-2xl shadow-2xl overflow-hidden border border-slate-200">
          <ChatWidget config={config} preview={true} />
        </div>

        <div className="mt-6 text-center text-xs text-slate-500">
          <p>Test the widget by typing a message above</p>
        </div>
      </div>

      {/* Right: Embed Code */}
      <div className="w-96 bg-white border-l border-slate-200 p-8 overflow-y-auto">
        <div className="mb-8">
          <h2 className="text-lg font-bold text-slate-900 mb-1 flex items-center gap-2">
            <Code className="w-5 h-5" />
            Embed Code
          </h2>
          <p className="text-sm text-slate-600">
            Copy and paste this code on your website to add the chat widget
          </p>
        </div>

        {/* Code Block */}
        <div className="mb-6 bg-slate-900 rounded-lg overflow-hidden border border-slate-700">
          <div className="bg-slate-800 px-4 py-3 border-b border-slate-700 flex items-center justify-between">
            <span className="text-xs font-mono text-slate-400">HTML</span>
            <button
              onClick={handleCopyCode}
              className="text-xs font-medium text-slate-300 hover:text-white flex items-center gap-1
                         transition-colors"
            >
              {copied
                ? <>
                    <Check className="w-3 h-3 text-green-400" />
                    Copied
                  </>
                : <>
                    <Copy className="w-3 h-3" />
                    Copy
                  </>
              }
            </button>
          </div>
          <pre className="px-4 py-4 text-xs font-mono text-slate-100 overflow-x-auto">
            <code>{embedCode}</code>
          </pre>
        </div>

        {/* Instructions */}
        <div className="space-y-4 mb-8">
          <div>
            <h3 className="font-semibold text-slate-900 text-sm mb-2">Setup Instructions</h3>
            <ol className="text-sm text-slate-600 space-y-2 list-decimal list-inside">
              <li>Copy the code above</li>
              <li>Paste it before the closing <code className="bg-slate-100 px-1 py-0.5 rounded text-xs">&lt;/body&gt;</code> tag on your website</li>
              <li>The widget will automatically appear in the bottom right</li>
              <li>Visitors can start chatting immediately</li>
            </ol>
          </div>

          <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
            <p className="text-xs text-blue-900">
              <strong>Note:</strong> The widget works on any website. No special setup required — just paste the code!
            </p>
          </div>
        </div>

        {/* Stats */}
        <div className="pt-6 border-t border-slate-200">
          <h3 className="font-semibold text-slate-900 text-sm mb-4">Widget Details</h3>
          <div className="space-y-3 text-sm">
            <div>
              <span className="text-slate-500">Business:</span>
              <p className="text-slate-900 font-medium">{config.business_name}</p>
            </div>
            <div>
              <span className="text-slate-500">AI Receptionist:</span>
              <p className="text-slate-900 font-medium">{config.ai_persona_name}</p>
            </div>
            <div>
              <span className="text-slate-500">Color:</span>
              <div className="flex items-center gap-2 mt-1">
                <div
                  className="w-8 h-8 rounded-lg border border-slate-200"
                  style={{ background: config.primary_color }}
                />
                <code className="text-xs bg-slate-100 px-2 py-1 rounded">{config.primary_color}</code>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
