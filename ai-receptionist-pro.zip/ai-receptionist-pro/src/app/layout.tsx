import type { Metadata, Viewport } from 'next'
import './globals.css'
import { Toaster } from 'react-hot-toast'

export const metadata: Metadata = {
  title: {
    default: 'AI Receptionist Pro — 24/7 AI for Local Businesses',
    template: '%s | AI Receptionist Pro',
  },
  description:
    'Replace your front desk with an AI that answers questions, captures leads, and books appointments 24/7. Trusted by 10,000+ local businesses.',
  keywords: ['AI receptionist', 'chatbot', 'lead capture', 'local business', '24/7'],
  authors: [{ name: 'AI Receptionist Pro' }],
  openGraph: {
    title: 'AI Receptionist Pro — Never Miss a Lead Again',
    description: 'Affordable 24/7 AI receptionist for dentists, law firms, HVAC, real estate, and more.',
    type: 'website',
  },
}

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  maximumScale: 1,
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="scroll-smooth">
      <body className="min-h-screen antialiased">
        <Toaster
          position="top-right"
          toastOptions={{
            duration: 4000,
            className: 'text-sm font-medium shadow-dropdown',
            success: { iconTheme: { primary: '#16a34a', secondary: '#fff' } },
            error:   { iconTheme: { primary: '#dc2626', secondary: '#fff' } },
          }}
        />
        {children}
      </body>
    </html>
  )
}
