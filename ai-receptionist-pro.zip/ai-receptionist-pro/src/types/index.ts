// ============================================
// AI RECEPTIONIST PRO - TYPE DEFINITIONS
// ============================================

export type Industry =
  | 'dental'
  | 'real_estate'
  | 'law_firm'
  | 'plumbing'
  | 'hvac'
  | 'roofing'
  | 'medical'
  | 'insurance'
  | 'other'

export type SubscriptionPlan = 'starter' | 'professional' | 'agency'
export type SubscriptionStatus = 'active' | 'canceled' | 'past_due' | 'trialing'
export type LeadScore = 'hot' | 'warm' | 'cold'
export type AppointmentStatus = 'scheduled' | 'confirmed' | 'cancelled' | 'completed' | 'no_show'
export type ConversationStatus = 'active' | 'closed' | 'pending'
export type NotificationType = 'new_lead' | 'appointment_booked' | 'appointment_cancelled' | 'system'
export type UserRole = 'admin' | 'business_owner'

// ---- User & Auth ----
export interface User {
  id: string
  email: string
  full_name: string | null
  avatar_url: string | null
  role: UserRole
  created_at: string
  updated_at: string
}

// ---- Business Profile ----
export interface BusinessProfile {
  id: string
  user_id: string
  business_name: string
  industry: Industry
  website: string | null
  phone: string | null
  email: string | null
  address: string | null
  city: string | null
  state: string | null
  zip: string | null
  description: string | null
  logo_url: string | null
  timezone: string
  business_hours: BusinessHours
  services: Service[]
  faqs: FAQ[]
  custom_greeting: string | null
  ai_persona_name: string
  widget_color: string
  widget_position: 'bottom-right' | 'bottom-left'
  is_active: boolean
  created_at: string
  updated_at: string
}

export interface BusinessHours {
  monday:    DayHours
  tuesday:   DayHours
  wednesday: DayHours
  thursday:  DayHours
  friday:    DayHours
  saturday:  DayHours
  sunday:    DayHours
}

export interface DayHours {
  open:  boolean
  start: string  // "09:00"
  end:   string  // "17:00"
}

export interface Service {
  id: string
  name: string
  description: string
  duration: number  // minutes
  price: number | null
}

export interface FAQ {
  id: string
  question: string
  answer: string
}

// ---- Subscription ----
export interface Subscription {
  id: string
  user_id: string
  stripe_customer_id: string | null
  stripe_subscription_id: string | null
  plan: SubscriptionPlan
  status: SubscriptionStatus
  chats_used: number
  chats_limit: number
  current_period_start: string | null
  current_period_end: string | null
  created_at: string
  updated_at: string
}

// ---- Conversation / Chat ----
export interface Conversation {
  id: string
  business_id: string
  visitor_id: string
  visitor_name: string | null
  visitor_email: string | null
  visitor_phone: string | null
  status: ConversationStatus
  lead_id: string | null
  messages: Message[]
  source: string | null
  created_at: string
  updated_at: string
  closed_at: string | null
}

export interface Message {
  id: string
  conversation_id: string
  role: 'user' | 'assistant' | 'system'
  content: string
  metadata: Record<string, unknown> | null
  created_at: string
}

// ---- Lead ----
export interface Lead {
  id: string
  business_id: string
  conversation_id: string | null
  name: string
  email: string | null
  phone: string | null
  service_needed: string | null
  preferred_date: string | null
  score: LeadScore
  notes: string | null
  source: string | null
  is_converted: boolean
  created_at: string
  updated_at: string
}

// ---- Appointment ----
export interface Appointment {
  id: string
  business_id: string
  lead_id: string | null
  customer_name: string
  customer_email: string | null
  customer_phone: string | null
  service: string
  status: AppointmentStatus
  start_time: string
  end_time: string
  notes: string | null
  google_event_id: string | null
  reminder_sent: boolean
  created_at: string
  updated_at: string
}

// ---- Notification ----
export interface Notification {
  id: string
  user_id: string
  type: NotificationType
  title: string
  message: string
  read: boolean
  metadata: Record<string, unknown> | null
  created_at: string
}

// ---- Dashboard Stats ----
export interface DashboardStats {
  total_conversations: number
  total_leads: number
  total_appointments: number
  conversion_rate: number
  conversations_this_month: number
  leads_this_month: number
  appointments_this_month: number
  hot_leads: number
  warm_leads: number
  cold_leads: number
  chats_used: number
  chats_limit: number
}

// ---- API Responses ----
export interface ApiResponse<T = void> {
  success: boolean
  data?: T
  error?: string
  message?: string
}

// ---- Chat Widget ----
export interface ChatConfig {
  business_id: string
  business_name: string
  ai_persona_name: string
  custom_greeting: string | null
  primary_color: string
  position: 'bottom-right' | 'bottom-left'
}
