-- ============================================================
-- AI RECEPTIONIST PRO — SUPABASE DATABASE SCHEMA
-- ============================================================
-- Run this in Supabase SQL Editor to set up all tables.
-- Tables use Row Level Security (RLS) for data protection.
-- ============================================================

-- Enable required extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ============================================================
-- USERS TABLE (extends Supabase auth.users)
-- ============================================================
CREATE TABLE IF NOT EXISTS public.users (
  id            UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email         TEXT NOT NULL UNIQUE,
  full_name     TEXT,
  avatar_url    TEXT,
  role          TEXT NOT NULL DEFAULT 'business_owner' CHECK (role IN ('admin', 'business_owner')),
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own profile" ON public.users
  FOR SELECT USING (auth.uid() = id);

CREATE POLICY "Users can update own profile" ON public.users
  FOR UPDATE USING (auth.uid() = id);

CREATE POLICY "Admins can view all users" ON public.users
  FOR ALL USING (
    EXISTS (SELECT 1 FROM public.users WHERE id = auth.uid() AND role = 'admin')
  );

-- ============================================================
-- BUSINESS PROFILES TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS public.business_profiles (
  id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id             UUID NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  business_name       TEXT NOT NULL,
  industry            TEXT NOT NULL DEFAULT 'other',
  website             TEXT,
  phone               TEXT,
  email               TEXT,
  address             TEXT,
  city                TEXT,
  state               TEXT,
  zip                 TEXT,
  description         TEXT,
  logo_url            TEXT,
  timezone            TEXT NOT NULL DEFAULT 'America/New_York',
  business_hours      JSONB NOT NULL DEFAULT '{
    "monday":    {"open": true,  "start": "09:00", "end": "17:00"},
    "tuesday":   {"open": true,  "start": "09:00", "end": "17:00"},
    "wednesday": {"open": true,  "start": "09:00", "end": "17:00"},
    "thursday":  {"open": true,  "start": "09:00", "end": "17:00"},
    "friday":    {"open": true,  "start": "09:00", "end": "17:00"},
    "saturday":  {"open": false, "start": "09:00", "end": "13:00"},
    "sunday":    {"open": false, "start": "09:00", "end": "13:00"}
  }',
  services            JSONB NOT NULL DEFAULT '[]',
  faqs                JSONB NOT NULL DEFAULT '[]',
  custom_greeting     TEXT,
  ai_persona_name     TEXT NOT NULL DEFAULT 'Alex',
  widget_color        TEXT NOT NULL DEFAULT '#0c7eea',
  widget_position     TEXT NOT NULL DEFAULT 'bottom-right',
  is_active           BOOLEAN NOT NULL DEFAULT true,
  created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

ALTER TABLE public.business_profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can manage own business" ON public.business_profiles
  FOR ALL USING (auth.uid() = user_id);

CREATE POLICY "Widget can read business by id" ON public.business_profiles
  FOR SELECT USING (true);  -- Public read for widget

-- ============================================================
-- SUBSCRIPTIONS TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS public.subscriptions (
  id                        UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id                   UUID NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  stripe_customer_id        TEXT,
  stripe_subscription_id    TEXT,
  plan                      TEXT NOT NULL DEFAULT 'starter' CHECK (plan IN ('starter', 'professional', 'agency')),
  status                    TEXT NOT NULL DEFAULT 'trialing' CHECK (status IN ('active', 'canceled', 'past_due', 'trialing')),
  chats_used                INTEGER NOT NULL DEFAULT 0,
  chats_limit               INTEGER NOT NULL DEFAULT 100,
  current_period_start      TIMESTAMPTZ,
  current_period_end        TIMESTAMPTZ,
  created_at                TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at                TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

ALTER TABLE public.subscriptions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own subscription" ON public.subscriptions
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Service role can manage subscriptions" ON public.subscriptions
  FOR ALL USING (true);

-- ============================================================
-- CONVERSATIONS TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS public.conversations (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  business_id     UUID NOT NULL REFERENCES public.business_profiles(id) ON DELETE CASCADE,
  visitor_id      TEXT NOT NULL,
  visitor_name    TEXT,
  visitor_email   TEXT,
  visitor_phone   TEXT,
  status          TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'closed', 'pending')),
  lead_id         UUID,
  source          TEXT DEFAULT 'widget',
  metadata        JSONB DEFAULT '{}',
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  closed_at       TIMESTAMPTZ
);

ALTER TABLE public.conversations ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Business owners can view own conversations" ON public.conversations
  FOR SELECT USING (
    business_id IN (SELECT id FROM public.business_profiles WHERE user_id = auth.uid())
  );

CREATE POLICY "Widget can create conversations" ON public.conversations
  FOR INSERT WITH CHECK (true);

CREATE POLICY "Widget can update conversations" ON public.conversations
  FOR UPDATE USING (true);

-- ============================================================
-- MESSAGES TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS public.messages (
  id                UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  conversation_id   UUID NOT NULL REFERENCES public.conversations(id) ON DELETE CASCADE,
  role              TEXT NOT NULL CHECK (role IN ('user', 'assistant', 'system')),
  content           TEXT NOT NULL,
  metadata          JSONB DEFAULT '{}',
  created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

ALTER TABLE public.messages ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Business owners can view messages" ON public.messages
  FOR SELECT USING (
    conversation_id IN (
      SELECT c.id FROM public.conversations c
      JOIN public.business_profiles b ON c.business_id = b.id
      WHERE b.user_id = auth.uid()
    )
  );

CREATE POLICY "Widget can insert messages" ON public.messages
  FOR INSERT WITH CHECK (true);

-- ============================================================
-- LEADS TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS public.leads (
  id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  business_id         UUID NOT NULL REFERENCES public.business_profiles(id) ON DELETE CASCADE,
  conversation_id     UUID REFERENCES public.conversations(id) ON DELETE SET NULL,
  name                TEXT NOT NULL,
  email               TEXT,
  phone               TEXT,
  service_needed      TEXT,
  preferred_date      TEXT,
  score               TEXT NOT NULL DEFAULT 'cold' CHECK (score IN ('hot', 'warm', 'cold')),
  notes               TEXT,
  source              TEXT DEFAULT 'ai_chat',
  is_converted        BOOLEAN NOT NULL DEFAULT false,
  tags                TEXT[] DEFAULT '{}',
  created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

ALTER TABLE public.leads ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Business owners can manage own leads" ON public.leads
  FOR ALL USING (
    business_id IN (SELECT id FROM public.business_profiles WHERE user_id = auth.uid())
  );

CREATE POLICY "Service role can insert leads" ON public.leads
  FOR INSERT WITH CHECK (true);

-- ============================================================
-- APPOINTMENTS TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS public.appointments (
  id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  business_id         UUID NOT NULL REFERENCES public.business_profiles(id) ON DELETE CASCADE,
  lead_id             UUID REFERENCES public.leads(id) ON DELETE SET NULL,
  customer_name       TEXT NOT NULL,
  customer_email      TEXT,
  customer_phone      TEXT,
  service             TEXT NOT NULL,
  status              TEXT NOT NULL DEFAULT 'scheduled' CHECK (status IN ('scheduled', 'confirmed', 'cancelled', 'completed', 'no_show')),
  start_time          TIMESTAMPTZ NOT NULL,
  end_time            TIMESTAMPTZ NOT NULL,
  notes               TEXT,
  google_event_id     TEXT,
  reminder_sent       BOOLEAN NOT NULL DEFAULT false,
  created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

ALTER TABLE public.appointments ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Business owners can manage own appointments" ON public.appointments
  FOR ALL USING (
    business_id IN (SELECT id FROM public.business_profiles WHERE user_id = auth.uid())
  );

CREATE POLICY "Service role can manage appointments" ON public.appointments
  FOR INSERT WITH CHECK (true);

-- ============================================================
-- NOTIFICATIONS TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS public.notifications (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id     UUID NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  type        TEXT NOT NULL CHECK (type IN ('new_lead', 'appointment_booked', 'appointment_cancelled', 'system')),
  title       TEXT NOT NULL,
  message     TEXT NOT NULL,
  read        BOOLEAN NOT NULL DEFAULT false,
  metadata    JSONB DEFAULT '{}',
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own notifications" ON public.notifications
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can update own notifications" ON public.notifications
  FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "Service role can insert notifications" ON public.notifications
  FOR INSERT WITH CHECK (true);

-- ============================================================
-- GOOGLE CALENDAR TOKENS TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS public.calendar_tokens (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id         UUID NOT NULL REFERENCES public.users(id) ON DELETE CASCADE UNIQUE,
  access_token    TEXT NOT NULL,
  refresh_token   TEXT,
  expiry_date     BIGINT,
  calendar_id     TEXT DEFAULT 'primary',
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

ALTER TABLE public.calendar_tokens ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can manage own calendar tokens" ON public.calendar_tokens
  FOR ALL USING (auth.uid() = user_id);

-- ============================================================
-- INDEXES FOR PERFORMANCE
-- ============================================================
CREATE INDEX idx_conversations_business_id    ON public.conversations(business_id);
CREATE INDEX idx_conversations_visitor_id     ON public.conversations(visitor_id);
CREATE INDEX idx_conversations_status         ON public.conversations(status);
CREATE INDEX idx_messages_conversation_id     ON public.messages(conversation_id);
CREATE INDEX idx_leads_business_id            ON public.leads(business_id);
CREATE INDEX idx_leads_score                  ON public.leads(score);
CREATE INDEX idx_leads_created_at             ON public.leads(created_at DESC);
CREATE INDEX idx_appointments_business_id     ON public.appointments(business_id);
CREATE INDEX idx_appointments_start_time      ON public.appointments(start_time);
CREATE INDEX idx_appointments_status          ON public.appointments(status);
CREATE INDEX idx_notifications_user_id        ON public.notifications(user_id);
CREATE INDEX idx_notifications_read           ON public.notifications(read);

-- ============================================================
-- UPDATED_AT TRIGGER FUNCTION
-- ============================================================
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_users_updated_at
  BEFORE UPDATE ON public.users
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_business_profiles_updated_at
  BEFORE UPDATE ON public.business_profiles
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_subscriptions_updated_at
  BEFORE UPDATE ON public.subscriptions
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_conversations_updated_at
  BEFORE UPDATE ON public.conversations
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_leads_updated_at
  BEFORE UPDATE ON public.leads
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_appointments_updated_at
  BEFORE UPDATE ON public.appointments
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- ============================================================
-- AUTO-CREATE USER PROFILE ON SIGNUP
-- ============================================================
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.users (id, email, full_name, avatar_url)
  VALUES (
    NEW.id,
    NEW.email,
    NEW.raw_user_meta_data->>'full_name',
    NEW.raw_user_meta_data->>'avatar_url'
  );

  -- Create default subscription (14-day trial)
  INSERT INTO public.subscriptions (user_id, plan, status, chats_limit, current_period_start, current_period_end)
  VALUES (
    NEW.id,
    'starter',
    'trialing',
    100,
    NOW(),
    NOW() + INTERVAL '14 days'
  );

  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();
